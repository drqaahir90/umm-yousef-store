package com.example.util

import com.example.model.ProductCategory

data class GeneratedCopy(
    val descriptionEn: String,
    val descriptionAr: String,
    val descriptionSo: String,
    val benefitsEn: List<String>,
    val benefitsAr: List<String>,
    val benefitsSo: List<String>,
    val ingredientsEn: String,
    val ingredientsAr: String,
    val ingredientsSo: String,
    val howToUseEn: String,
    val howToUseAr: String,
    val howToUseSo: String
)

object AiCopywriter {
    fun generateProductCopy(
        productName: String,
        category: ProductCategory,
        keyIngredientsOrFeature: String
    ): GeneratedCopy {
        val cleanName = productName.trim().ifBlank { "Luxury Elixir" }
        val feature = keyIngredientsOrFeature.trim().ifBlank { "24K Gold & Moroccan Botanical Oils" }

        val descAr = when (category) {
            ProductCategory.SKINCARE -> "مستحضر فاخر للعناية الفائقة بالبشرة يحمل توقيع 'أم يوسف للجمال'. تم ابتكاره بعناية فائقة ليعيد للبشرة حيويتها ونضارتها الزجاجية الفاتنة من أول لمسة. غني بـ ($feature) الذي يعزز إنتاج الكولاجين الطبيعي ويوحد لون البشرة، لتتألقي بجمال طبيعي ساحر يجسد شعارنا: جمالك الطبيعي، لمستنا الساحرة."
            ProductCategory.PERFUMES_OUD -> "أيقونة عطرية شرقية مترفة تمزج بين أرقى النفحات الملكية و($feature). يفتتح بنسمات ساحرة تأسرك من اللحظة الأولى، ثم يستقر على قاعدة دافئة من دهن العود المعتق والعنبر النادر. فوحان استثنائي وثبات ملكي يدوم طويلاً ليمنحك حضوراً لا ينسى."
            ProductCategory.HAIRCARE -> "إكسير مكثف لعلاج وتغذية الشعر من الجذور حتى الأطراف. بتركيبة غنية بخلاصات ($feature)، يوقف التساقط ويعيد إنبات الفراغات ويمنح خصلات شعرك كثافة ولمعاناً حريرياً فائق النعومة، مع حماية تامة من التقصف والتلف."
            ProductCategory.MAKEUP -> "لمسة جمالية ساحرة بملمس مخملي خفيف كالريشة يمنحك تألقاً طبيعياً يدوم طوال اليوم. تركيبة مبتكرة غنية بمرطبات طبيعية و($feature) تنساب بنعومة فائقة لتبرز ملامحك الجذابة دون أي تكتل."
            ProductCategory.BATH_BODY -> "طقس عناية استثنائي للجسم ينقلك إلى عالم الرفاهية والاسترخاء التام. غني بـ ($feature) والزيوت العطرية المغذية التي تمنح جلدك ملمساً كالحرير ورائحة فواحة تأسر الألباب طوال اليوم."
            ProductCategory.NATURAL_OILS -> "زيت نقي معصور على البارد بنقاء 100% مستخلص من ($feature). غني بمضادات الأكسدة والفيتامينات الحيوية لترطيب مكثف وتجديد فوري للبشرة والشعر."
            ProductCategory.ALL -> "مستحضر ملكي استثنائي يجمع بين نقاء الطبيعة وفخامة العناية، غني بـ ($feature) ليمنحك تجربة تجميلية راقية."
        }

        val descEn = "An opulent beauty masterpiece by Umm Yousef Beauty, formulated to reveal your radiant natural elegance. Powered by $feature to deliver transformative nourishment, cellular hydration, and an irresistible velvety glow. Truly your natural beauty, elevated by our charming touch."

        val descSo = "Agab quruxeed heersare ah oo ay soo saartay Umm Yousef Beauty. Waxaa lagu qasay $feature si uu maqaarkaaga iyo timahaaga u siiyo daryeel buuxa, dhalaal dabiici ah iyo iftiin boqornimo. Quruxdaada dabiiciga ah, taabashadayada soo jiidashada leh."

        val benefitsAr = listOf(
            "إشراقة ونضارة فورية للبشرة",
            "تركيبة طبيعية غنية بـ $feature",
            "ثبات ونتائج ملحوظة من أول أسبوع",
            "مناسب لجميع أنواع البشرة وخالٍ من المواد الضارة"
        )

        val benefitsEn = listOf(
            "Instant luminous radiance & glow",
            "Infused with nutrient-rich $feature",
            "Clinically proven visible results in 7 days",
            "Clean, dermatologically tested luxury formula"
        )

        val benefitsSo = listOf(
            "Iftiin degdeg ah iyo dhalanteed dabiici ah",
            "Ka samaysan nuxurka dabiiciga ah ee $feature",
            "Natiijo la arko todobaad gudihiis",
            "U roon nooc kasta oo maqaarka ah"
        )

        val ingAr = "مستخلص ($feature)، حمض الهيالورونيك النقي، فيتامين E، زيت بذور الورد، صبار طبيعي عضوي."
        val ingEn = "Active Extract of $feature, Pure Hyaluronic Acid, Vitamin E, Rosehip Seed Oil, Organic Aloe Vera Leaf Juice."
        val ingSo = "Nuxurka $feature, Hyaluronic Acid, Fiitamiin E, Saliidda Rosehip, Dacar Dabiici ah."

        val useAr = "يستخدم مرتين يومياً صباحاً ومساءً على بشرة نظيفة بحركات دائرية ناعمة حتى تمتصه البشرة بالكامل."
        val useEn = "Apply gently morning and evening to cleansed skin using upward circular strokes until fully absorbed."
        val useSo = "Marso subaxii iyo habeenkii wajiga oo nadiif ah adoo si tartiib ah ugu daliigaya ilaa uu maqaarku nuugo."

        return GeneratedCopy(
            descriptionEn = descEn,
            descriptionAr = descAr,
            descriptionSo = descSo,
            benefitsEn = benefitsEn,
            benefitsAr = benefitsAr,
            benefitsSo = benefitsSo,
            ingredientsEn = ingEn,
            ingredientsAr = ingAr,
            ingredientsSo = ingSo,
            howToUseEn = useEn,
            howToUseAr = useAr,
            howToUseSo = useSo
        )
    }
}

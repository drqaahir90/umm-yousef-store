package com.example.util

import com.example.model.AppLanguage
import com.example.model.ProductCategory

object AppStrings {
    // Slogans & Branding
    const val BRAND_NAME_AR = "أم يوسف للجمال"
    const val BRAND_NAME_EN = "Umm Yousef Beauty"
    const val BRAND_NAME_SO = "Umm Yousef Quruxda"

    const val SLOGAN_AR = "جمالك الطبيعي، لمستنا الساحرة"
    const val SLOGAN_EN = "Your natural beauty, our charming touch"
    const val SLOGAN_SO = "Quruxdaada dabiiciga ah, taabashadayada soo jiidashada leh"

    const val PROMO_BANNER_AR = "عرض الشهر: احصل على خصم 25% على جميع المنتجات!"
    const val PROMO_BANNER_EN = "Special Offer: Enjoy 25% OFF all luxury cosmetics!"
    const val PROMO_BANNER_SO = "Dalabka Bisha: Ka hel 25% dhimis dhammaan agabka quruxda!"

    const val OWNER_PHONE = "0613679490"
    const val OWNER_PHONE_INTL = "252613679490"
    const val OWNER_EMAIL = "umysf888@gmail.com"
    const val OWNER_TIKTOK = "@ummyousef40"
    const val OWNER_INSTAGRAM = "um_yusuf_"

    fun brandName(lang: AppLanguage): String = when (lang) {
        AppLanguage.ARABIC -> BRAND_NAME_AR
        AppLanguage.SOMALI -> BRAND_NAME_SO
        AppLanguage.ENGLISH -> BRAND_NAME_EN
    }

    fun slogan(lang: AppLanguage): String = when (lang) {
        AppLanguage.ARABIC -> SLOGAN_AR
        AppLanguage.SOMALI -> SLOGAN_SO
        AppLanguage.ENGLISH -> SLOGAN_EN
    }

    fun promoBanner(lang: AppLanguage): String = when (lang) {
        AppLanguage.ARABIC -> PROMO_BANNER_AR
        AppLanguage.SOMALI -> PROMO_BANNER_SO
        AppLanguage.ENGLISH -> PROMO_BANNER_EN
    }

    // Categories
    fun categoryName(category: ProductCategory, lang: AppLanguage): String = when (category) {
        ProductCategory.ALL -> when (lang) {
            AppLanguage.ARABIC -> "الكل"
            AppLanguage.SOMALI -> "Dhammaan"
            AppLanguage.ENGLISH -> "All"
        }
        ProductCategory.SKINCARE -> when (lang) {
            AppLanguage.ARABIC -> "العناية بالبشرة"
            AppLanguage.SOMALI -> "Daryeelka Jirka"
            AppLanguage.ENGLISH -> "Skincare"
        }
        ProductCategory.HAIRCARE -> when (lang) {
            AppLanguage.ARABIC -> "العناية بالشعر"
            AppLanguage.SOMALI -> "Daryeelka Timaha"
            AppLanguage.ENGLISH -> "Haircare"
        }
        ProductCategory.PERFUMES_OUD -> when (lang) {
            AppLanguage.ARABIC -> "العطور والعود"
            AppLanguage.SOMALI -> "Baraafiin & Cuud"
            AppLanguage.ENGLISH -> "Perfumes & Oud"
        }
        ProductCategory.MAKEUP -> when (lang) {
            AppLanguage.ARABIC -> "المكياج"
            AppLanguage.SOMALI -> "Qurxinta Wajiga"
            AppLanguage.ENGLISH -> "Makeup"
        }
        ProductCategory.BATH_BODY -> when (lang) {
            AppLanguage.ARABIC -> "الحمام والجسم"
            AppLanguage.SOMALI -> "Maydhashada & Jirka"
            AppLanguage.ENGLISH -> "Bath & Body"
        }
        ProductCategory.NATURAL_OILS -> when (lang) {
            AppLanguage.ARABIC -> "الزيوت الطبيعية"
            AppLanguage.SOMALI -> "Saliidaha Dabiiciga"
            AppLanguage.ENGLISH -> "Natural Oils"
        }
    }

    // UI Labels
    fun searchHint(lang: AppLanguage): String = when (lang) {
        AppLanguage.ARABIC -> "ابحث عن أي منتج تجميلي أو بالحرف..."
        AppLanguage.SOMALI -> "Raadi badeeco kasta ama xaraf..."
        AppLanguage.ENGLISH -> "Search cosmetics by name or alphabet..."
    }

    fun filterAllLetters(lang: AppLanguage): String = when (lang) {
        AppLanguage.ARABIC -> "الكل"
        AppLanguage.SOMALI -> "Dhammaan"
        AppLanguage.ENGLISH -> "All"
    }

    fun addToBasket(lang: AppLanguage): String = when (lang) {
        AppLanguage.ARABIC -> "أضف للسلة"
        AppLanguage.SOMALI -> "Ku dar Dambiisha"
        AppLanguage.ENGLISH -> "Add to Basket"
    }

    fun orderNow(lang: AppLanguage): String = when (lang) {
        AppLanguage.ARABIC -> "اطلب الآن"
        AppLanguage.SOMALI -> "Dalbo Hadda"
        AppLanguage.ENGLISH -> "Order Now"
    }

    fun basket(lang: AppLanguage): String = when (lang) {
        AppLanguage.ARABIC -> "سلة المشتريات"
        AppLanguage.SOMALI -> "Dambiisha Gadashada"
        AppLanguage.ENGLISH -> "Shopping Basket"
    }

    fun emptyBasket(lang: AppLanguage): String = when (lang) {
        AppLanguage.ARABIC -> "سلة المشتريات فارغة. استكشفي مجموعتنا الفاخرة!"
        AppLanguage.SOMALI -> "Dambiishaadu way maran tahay. Baadh agabkeena qiimaha leh!"
        AppLanguage.ENGLISH -> "Your basket is empty. Explore our luxury collection!"
    }

    fun subtotal(lang: AppLanguage): String = when (lang) {
        AppLanguage.ARABIC -> "المجموع الفرعي"
        AppLanguage.SOMALI -> "Wadarta Hoose"
        AppLanguage.ENGLISH -> "Subtotal"
    }

    fun discount(lang: AppLanguage): String = when (lang) {
        AppLanguage.ARABIC -> "خصم العرض (25%)"
        AppLanguage.SOMALI -> "Dhimis Gaar ah (25%)"
        AppLanguage.ENGLISH -> "Campaign Discount (25%)"
    }

    fun total(lang: AppLanguage): String = when (lang) {
        AppLanguage.ARABIC -> "الإجمالي للدفع"
        AppLanguage.SOMALI -> "Wadarta Guud"
        AppLanguage.ENGLISH -> "Total Amount"
    }

    fun proceedToCheckout(lang: AppLanguage): String = when (lang) {
        AppLanguage.ARABIC -> "متابعة الدفع والطلب"
        AppLanguage.SOMALI -> "U gudub Bixinta & Dalabka"
        AppLanguage.ENGLISH -> "Proceed to Checkout"
    }

    // Checkout & Payment Methods
    fun paymentMethod(lang: AppLanguage): String = when (lang) {
        AppLanguage.ARABIC -> "اختر طريقة الدفع"
        AppLanguage.SOMALI -> "Dooro Habka Bixinta"
        AppLanguage.ENGLISH -> "Select Payment Method"
    }

    fun evcPlusTitle(lang: AppLanguage): String = when (lang) {
        AppLanguage.ARABIC -> "الدفع الفوري عبر EVC Plus (*712*)"
        AppLanguage.SOMALI -> "Bixin Toos ah: EVC Plus (*712*)"
        AppLanguage.ENGLISH -> "Instant Payment via EVC Plus (*712*)"
    }

    fun evcPlusSubtitle(lang: AppLanguage): String = when (lang) {
        AppLanguage.ARABIC -> "يفتح تطبيق الاتصال مباشرة لإتمام عملية التحويل الفوري"
        AppLanguage.SOMALI -> "Toos u furaya wicitaanka taleefanka si aad lacagta ugu dirto"
        AppLanguage.ENGLISH -> "Directly opens phone dialer with USSD code to complete payment"
    }

    fun openDialer(lang: AppLanguage): String = when (lang) {
        AppLanguage.ARABIC -> "فتح تطبيق الاتصال للدفع (*712*)"
        AppLanguage.SOMALI -> "Fur Wicitaanka Taleefanka (*712*)"
        AppLanguage.ENGLISH -> "Open Phone Dialer (*712*)"
    }

    fun debitOptionTitle(lang: AppLanguage): String = when (lang) {
        AppLanguage.ARABIC -> "الدفع بالآجل / سلف (Pay Later - Deyn)"
        AppLanguage.SOMALI -> "Deyn / Bixi Maalmo Kadib (Pay Later)"
        AppLanguage.ENGLISH -> "Pay Later / Debit (Debt with NIRA ID)"
    }

    fun debitOptionSubtitle(lang: AppLanguage): String = when (lang) {
        AppLanguage.ARABIC -> "للعملاء الموثقين: ادفع بعد أيام مع إرفاق بطاقة الهوية الوطنية NIRA"
        AppLanguage.SOMALI -> "Macaamiisha la hubo: Bixi maalmo kadib adoo soo galinaya aqoonsiga NIRA"
        AppLanguage.ENGLISH -> "Pay after a few days with verified NIRA National ID submission"
    }

    // Debit Form Fields
    fun debitFormTitle(lang: AppLanguage): String = when (lang) {
        AppLanguage.ARABIC -> "طلب الشراء بالآجل (الدين الموثق)"
        AppLanguage.SOMALI -> "Codsiga Qaadashada Deynta (NIRA ID)"
        AppLanguage.ENGLISH -> "Debit / Pay Later Application"
    }

    fun fullNameNationalId(lang: AppLanguage): String = when (lang) {
        AppLanguage.ARABIC -> "الاسم الكامل كما هو مسجل في بطاقة الهوية الوطنية NIRA"
        AppLanguage.SOMALI -> "Magacaaga buuxa sida ku qoran Kaarka Aqoonsiga NIRA"
        AppLanguage.ENGLISH -> "Full Name exactly as on National ID / NIRA Card"
    }

    fun phoneNumber(lang: AppLanguage): String = when (lang) {
        AppLanguage.ARABIC -> "رقم الهاتف الفعلي (الصومال أو دولي)"
        AppLanguage.SOMALI -> "Lambarka Taleefanka saxda ah"
        AppLanguage.ENGLISH -> "Real Phone Number (Somalia / International)"
    }

    fun placeOrCity(lang: AppLanguage): String = when (lang) {
        AppLanguage.ARABIC -> "المدينة والحي / العنوان التفصيلي للتوصيل"
        AppLanguage.SOMALI -> "Magaalada, Degmada & Goobta deggan tahay"
        AppLanguage.ENGLISH -> "City, District & Delivery Location"
    }

    fun promisedPaymentDate(lang: AppLanguage): String = when (lang) {
        AppLanguage.ARABIC -> "تاريخ ووقت سداد المبلغ المتفق عليه"
        AppLanguage.SOMALI -> "Taariikhda aad bixinayso lacagta"
        AppLanguage.ENGLISH -> "Promised Payment Due Date"
    }

    fun uploadNiraFront(lang: AppLanguage): String = when (lang) {
        AppLanguage.ARABIC -> "صورة الهوية الوطنية (الجهة الأمامية)"
        AppLanguage.SOMALI -> "Sawirka Aqoonsiga NIRA (Qaybta Hore)"
        AppLanguage.ENGLISH -> "NIRA National ID (Front Side Photo)"
    }

    fun uploadNiraBack(lang: AppLanguage): String = when (lang) {
        AppLanguage.ARABIC -> "صورة الهوية الوطنية (الجهة الخلفية)"
        AppLanguage.SOMALI -> "Sawirka Aqoonsiga NIRA (Qaybta Dambe)"
        AppLanguage.ENGLISH -> "NIRA National ID (Back Side Photo)"
    }

    fun submitDebitToWhatsApp(lang: AppLanguage): String = when (lang) {
        AppLanguage.ARABIC -> "إرسال طلب الآجل إلى واتساب الإدارة (0613679490)"
        AppLanguage.SOMALI -> "U dir Codsiga WhatsApp-ka Mulkiilaha (0613679490)"
        AppLanguage.ENGLISH -> "Send Debit Request to Owner WhatsApp (0613679490)"
    }

    fun ownerReviewNotice(lang: AppLanguage): String = when (lang) {
        AppLanguage.ARABIC -> "سيقوم صاحب المتجر بمراجعة الطلب والمستندات وإرسال الموافقة أو الرفض عبر واتساب"
        AppLanguage.SOMALI -> "Mulkiilaha dukaanka ayaa eegi doona codsiga kadibna kuugu soo jawaabi doona ogolaansho ama diidmo"
        AppLanguage.ENGLISH -> "The store owner will review the NIRA ID documents and send approval or rejection on WhatsApp"
    }

    // Owner Portal
    const val OWNER_DEFAULT_PIN = "79490"

    fun ownerPortal(lang: AppLanguage): String = when (lang) {
        AppLanguage.ARABIC -> "بوابة الإدارة وصاحب المتجر"
        AppLanguage.SOMALI -> "Albaabka Mulkiilaha & Maamulka"
        AppLanguage.ENGLISH -> "Store Owner & Admin Portal"
    }

    fun enterPin(lang: AppLanguage): String = when (lang) {
        AppLanguage.ARABIC -> "أدخل رمز الدخول السري للإدارة"
        AppLanguage.SOMALI -> "Geli lambarka sirta ah ee maamulka"
        AppLanguage.ENGLISH -> "Enter Owner Access PIN"
    }

    fun aiCopywriter(lang: AppLanguage): String = when (lang) {
        AppLanguage.ARABIC -> "المساعد الذكي لكتابة وصف المنتجات"
        AppLanguage.SOMALI -> "Kaaliyaha AI ee qorista faahfaahinta"
        AppLanguage.ENGLISH -> "AI Luxury Copywriting Assistant"
    }

    fun generateDescriptionWithAi(lang: AppLanguage): String = when (lang) {
        AppLanguage.ARABIC -> "توليد وصف فاخر بالذكاء الاصطناعي"
        AppLanguage.SOMALI -> "Ku samee faahfaahin casri ah AI"
        AppLanguage.ENGLISH -> "Generate Luxury Description with AI"
    }

    fun addNewProduct(lang: AppLanguage): String = when (lang) {
        AppLanguage.ARABIC -> "إضافة منتج جديد"
        AppLanguage.SOMALI -> "Ku dar Badeeco Cusub"
        AppLanguage.ENGLISH -> "Add New Product"
    }

    fun editProduct(lang: AppLanguage): String = when (lang) {
        AppLanguage.ARABIC -> "تعديل المنتج"
        AppLanguage.SOMALI -> "Wax ka beddel Badeecada"
        AppLanguage.ENGLISH -> "Edit Product"
    }

    fun uploadProductPhoto(lang: AppLanguage): String = when (lang) {
        AppLanguage.ARABIC -> "رفع صورة المنتج من المعرض"
        AppLanguage.SOMALI -> "Ka soo qaad sawirka taleefankaaga"
        AppLanguage.ENGLISH -> "Upload Photo from Gallery"
    }

    fun debitRequestsTab(lang: AppLanguage): String = when (lang) {
        AppLanguage.ARABIC -> "طلبات السلف والآجل"
        AppLanguage.SOMALI -> "Codsiyada Deynta (NIRA)"
        AppLanguage.ENGLISH -> "Debit & Debt Applications"
    }

    fun approve(lang: AppLanguage): String = when (lang) {
        AppLanguage.ARABIC -> "موافقة"
        AppLanguage.SOMALI -> "Ogolaansho"
        AppLanguage.ENGLISH -> "Approve"
    }

    fun reject(lang: AppLanguage): String = when (lang) {
        AppLanguage.ARABIC -> "رفض"
        AppLanguage.SOMALI -> "Diidmo"
        AppLanguage.ENGLISH -> "Reject"
    }

    // Customer Onboarding
    fun registerTitle(lang: AppLanguage): String = when (lang) {
        AppLanguage.ARABIC -> "تسجيل عميل جديد والتواصل عبر واتساب"
        AppLanguage.SOMALI -> "Diiwaangelinta Macmiilka Cusub"
        AppLanguage.ENGLISH -> "Customer Registration & WhatsApp Save"
    }

    fun registerNotice(lang: AppLanguage): String = when (lang) {
        AppLanguage.ARABIC -> "يتم تسجيل العملاء بالاسم الكامل ورقم الهاتف المعتمد وربطهم مباشرة بواتساب المتجر 0613679490 لتسهيل التواصل"
        AppLanguage.SOMALI -> "Waxaa lagu diiwaangelinayaa magacaaga buuxa iyo taleefankaaga adoo toos ugu xirmaya WhatsApp-ka 0613679490"
        AppLanguage.ENGLISH -> "Registered by full name and verified phone number, linked directly with WhatsApp 0613679490 for premier service"
    }
}

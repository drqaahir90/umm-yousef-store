package com.example.util

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import com.example.model.CustomerProfile
import com.example.model.DebitRequest

object EVCPlusHelper {
    const val MERCHANT_NUMBER = "613679490"
    const val MERCHANT_PHONE_DISPLAY = "0613679490"

    fun generateUssdCode(amountUsd: Double): String {
        val amount = if (amountUsd % 1.0 == 0.0) {
            amountUsd.toInt().toString()
        } else {
            String.format(java.util.Locale.US, "%.1f", amountUsd)
        }
        return "*712*$MERCHANT_NUMBER*$amount#"
    }

    fun openDialer(context: Context, amountUsd: Double) {
        try {
            val amount = if (amountUsd % 1.0 == 0.0) {
                amountUsd.toInt().toString()
            } else {
                String.format(java.util.Locale.US, "%.1f", amountUsd)
            }
            // In Android dialer, hash '#' must be URL encoded as '%23'
            val uriString = "tel:*712*$MERCHANT_NUMBER*${amount}" + Uri.encode("#")
            val intent = Intent(Intent.ACTION_DIAL, Uri.parse(uriString)).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(intent)
        } catch (e: Exception) {
            Toast.makeText(context, "Could not open dialer: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }
}

object WhatsAppHelper {
    const val TARGET_WHATSAPP_NUMBER = "252613679490" // 0613679490 with Somalia country code

    fun openWhatsAppMessage(context: Context, text: String) {
        try {
            val encodedText = Uri.encode(text)
            val uri = Uri.parse("https://wa.me/$TARGET_WHATSAPP_NUMBER?text=$encodedText")
            val intent = Intent(Intent.ACTION_VIEW, uri).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(intent)
        } catch (e: Exception) {
            Toast.makeText(context, "WhatsApp error: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    fun sendDebitApplication(context: Context, request: DebitRequest) {
        val message = buildString {
            appendLine("🌟 *طلب شراء بالآجل جديد (Deyn / Debit Request)* 🌟")
            appendLine("━━━━━━━━━━━━━━━━━━━━━")
            appendLine("👤 *الاسم الكامل (NIRA ID):* ${request.fullName}")
            appendLine("📱 *رقم الهاتف:* ${request.phoneNumber}")
            appendLine("📍 *المكان / العنوان:* ${request.placeOrCity}")
            appendLine("📅 *تاريخ سداد المبلغ:* ${request.promisedPaymentDate}")
            appendLine("💰 *المبلغ الإجمالي:* $${String.format(java.util.Locale.US, "%.2f", request.totalAmountUsd)}")
            appendLine("🛍️ *تفاصيل المنتجات:*")
            appendLine(request.itemsSummary)
            appendLine("━━━━━━━━━━━━━━━━━━━━━")
            appendLine("🆔 *تم إرفاق صور بطاقة الهوية الوطنية NIRA (الوجهين الأمامي والخلفي) في التطبيق.*")
            appendLine("يرجى مراجعة الطلب والموافقة أو الرفض. شكراً لتسوقكم مع أم يوسف للجمال ✨")
        }
        openWhatsAppMessage(context, message)
    }

    fun sendCustomerContact(context: Context, customer: CustomerProfile) {
        val message = buildString {
            appendLine("مرحباً أم يوسف للجمال 👋")
            appendLine("أنا عميلة جديدة أود حفظ رقمي وتأكيد تسجيلي:")
            appendLine("👤 *الاسم:* ${customer.fullName}")
            appendLine("📱 *الهاتف:* ${customer.phoneNumber}")
            appendLine("📍 *المدينة:* ${customer.city}")
            appendLine("✨ *جمالك الطبيعي، لمستنا الساحرة* ✨")
        }
        openWhatsAppMessage(context, message)
    }

    fun sendDirectOrder(context: Context, itemsSummary: String, total: Double, customerName: String, phone: String) {
        val message = buildString {
            appendLine("👑 *طلب شراء جديد من متجر أم يوسف للجمال* 👑")
            appendLine("━━━━━━━━━━━━━━━━━━━━━")
            appendLine("👤 *العميل:* $customerName")
            appendLine("📱 *الهاتف:* $phone")
            appendLine("🛍️ *المنتجات:*")
            appendLine(itemsSummary)
            appendLine("💰 *الإجمالي:* $${String.format(java.util.Locale.US, "%.2f", total)}")
            appendLine("💳 *طريقة الدفع:* EVC Plus (*712*613679490*)")
            appendLine("━━━━━━━━━━━━━━━━━━━━━")
            appendLine("✨ جمالك الطبيعي، لمستنا الساحرة ✨")
        }
        openWhatsAppMessage(context, message)
    }
}

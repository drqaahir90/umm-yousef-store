package com.example.ui.screens

import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CreditCard
import androidx.compose.material.icons.filled.Dialpad
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.model.AppLanguage
import com.example.ui.StoreViewModel
import com.example.ui.theme.GoldBorderDark
import com.example.ui.theme.GoldBorderLight
import com.example.ui.theme.GoldGlow
import com.example.ui.theme.GoldMetallic
import com.example.ui.theme.WhatsAppGreen
import com.example.util.AppStrings
import com.example.util.EVCPlusHelper
import com.example.util.WhatsAppHelper

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CheckoutScreen(
    viewModel: StoreViewModel,
    onBackClick: () -> Unit,
    onOrderComplete: () -> Unit
) {
    val context = LocalContext.current
    val language by viewModel.currentLanguage.collectAsState()
    val total = viewModel.calculateTotal()
    val isDark = MaterialTheme.colorScheme.background.red < 0.2f

    // 0: EVC Plus Instant Dial, 1: Debit / Pay Later (NIRA ID)
    var selectedPaymentMethod by remember { mutableIntStateOf(0) }

    // Debit Form States
    val customerProfile by viewModel.customerProfile.collectAsState()
    var fullName by remember { mutableStateOf(customerProfile.fullName) }
    var phoneNumber by remember { mutableStateOf(customerProfile.phoneNumber) }
    var placeOrCity by remember { mutableStateOf(customerProfile.city) }
    var promisedPaymentDate by remember { mutableStateOf("In 7 Days (7 Maalmood)") }
    var frontIdUri by remember { mutableStateOf<String?>(null) }
    var backIdUri by remember { mutableStateOf<String?>(null) }
    var pledgeChecked by remember { mutableStateOf(false) }

    // Photo pickers for front and back NIRA ID
    val frontPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            frontIdUri = uri.toString()
        }
    }

    val backPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            backIdUri = uri.toString()
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = AppStrings.paymentMethod(language),
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                },
                navigationIcon = {
                    IconButton(
                        onClick = onBackClick,
                        modifier = Modifier.testTag("checkout_back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = if (isDark) GoldGlow else GoldMetallic
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                )
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
                .verticalScroll(rememberScrollState())
                .padding(16.dp)
        ) {
            // Order Total Header Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = if (isDark) Color(0xFF221C18) else Color(0xFFFAF3E6)
                ),
                border = BorderStroke(1.dp, if (isDark) GoldBorderDark else GoldBorderLight)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = AppStrings.total(language),
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "$${String.format(java.util.Locale.US, "%.2f", total)}",
                        fontSize = 28.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Serif,
                        color = if (isDark) GoldGlow else Color(0xFF8B6508)
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "EVC Plus: $${String.format(java.util.Locale.US, "%.1f", total)} USD",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = if (isDark) Color(0xFFD5C8BD) else Color(0xFF6B470D)
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Method Selector Tabs
            TabRow(
                selectedTabIndex = selectedPaymentMethod,
                containerColor = if (isDark) Color(0xFF1B1715) else Color(0xFFF5EEE3),
                contentColor = if (isDark) GoldGlow else Color(0xFFB8860B),
                indicator = { tabPositions ->
                    TabRowDefaults.SecondaryIndicator(
                        Modifier.tabIndicatorOffset(tabPositions[selectedPaymentMethod]),
                        color = if (isDark) GoldGlow else Color(0xFFB8860B)
                    )
                },
                modifier = Modifier
                    .clip(RoundedCornerShape(14.dp))
                    .border(1.dp, if (isDark) GoldBorderDark else GoldBorderLight, RoundedCornerShape(14.dp))
            ) {
                Tab(
                    selected = selectedPaymentMethod == 0,
                    onClick = { selectedPaymentMethod = 0 },
                    text = {
                        Text(
                            text = "EVC PLUS (*712*)",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    },
                    modifier = Modifier.testTag("tab_evc_plus")
                )
                Tab(
                    selected = selectedPaymentMethod == 1,
                    onClick = { selectedPaymentMethod = 1 },
                    text = {
                        Text(
                            text = when (language) {
                                AppLanguage.ARABIC -> "سلف / آجل (Deyn)"
                                AppLanguage.SOMALI -> "Deyn / NIRA ID"
                                AppLanguage.ENGLISH -> "Pay Later / Debit"
                            },
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    },
                    modifier = Modifier.testTag("tab_debit_pay_later")
                )
            }

            Spacer(modifier = Modifier.height(18.dp))

            // Tab 0: EVC Plus
            if (selectedPaymentMethod == 0) {
                EvcPlusPaymentSection(
                    totalAmount = total,
                    language = language,
                    isDark = isDark,
                    onOpenDialer = {
                        EVCPlusHelper.openDialer(context, total)
                    },
                    onConfirmWhatsApp = {
                        val itemsSummary = viewModel.getCartItemsSummary()
                        WhatsAppHelper.sendDirectOrder(
                            context = context,
                            itemsSummary = itemsSummary,
                            total = total,
                            customerName = if (fullName.isNotBlank()) fullName else "Valued Customer",
                            phone = phoneNumber
                        )
                        viewModel.clearCart()
                        onOrderComplete()
                    }
                )
            } else {
                // Tab 1: Debit / Pay Later with NIRA ID upload
                DebitPayLaterSection(
                    totalAmount = total,
                    language = language,
                    isDark = isDark,
                    fullName = fullName,
                    onFullNameChange = { fullName = it },
                    phoneNumber = phoneNumber,
                    onPhoneChange = { phoneNumber = it },
                    placeOrCity = placeOrCity,
                    onPlaceChange = { placeOrCity = it },
                    promisedDate = promisedPaymentDate,
                    onPromisedDateChange = { promisedPaymentDate = it },
                    frontIdUri = frontIdUri,
                    onPickFrontId = {
                        frontPickerLauncher.launch(
                            PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                        )
                    },
                    backIdUri = backIdUri,
                    onPickBackId = {
                        backPickerLauncher.launch(
                            PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                        )
                    },
                    pledgeChecked = pledgeChecked,
                    onPledgeChange = { pledgeChecked = it },
                    onSubmit = {
                        // Validation
                        if (fullName.trim().length < 4) {
                            Toast.makeText(context, "Please enter your full name as on your ID", Toast.LENGTH_SHORT).show()
                            return@DebitPayLaterSection
                        }
                        if (phoneNumber.trim().length < 7) {
                            Toast.makeText(context, "Please enter your real country phone number", Toast.LENGTH_SHORT).show()
                            return@DebitPayLaterSection
                        }
                        if (frontIdUri == null || backIdUri == null) {
                            Toast.makeText(context, "Please upload BOTH front and back photos of your NIRA ID", Toast.LENGTH_LONG).show()
                            return@DebitPayLaterSection
                        }
                        if (!pledgeChecked) {
                            Toast.makeText(context, "Please check the payment pledge agreement", Toast.LENGTH_SHORT).show()
                            return@DebitPayLaterSection
                        }

                        // Save profile and submit request
                        viewModel.saveCustomerProfile(fullName, phoneNumber, placeOrCity)
                        val itemsSummary = viewModel.getCartItemsSummary()
                        val req = viewModel.submitDebitRequest(
                            fullName = fullName,
                            phone = phoneNumber,
                            place = placeOrCity,
                            promisedDate = promisedPaymentDate,
                            frontIdUri = frontIdUri,
                            backIdUri = backIdUri,
                            itemsSummary = itemsSummary,
                            totalAmount = total
                        )

                        // Open WhatsApp to owner 0613679490
                        WhatsAppHelper.sendDebitApplication(context, req)
                        viewModel.clearCart()
                        onOrderComplete()
                    }
                )
            }
        }
    }
}

@Composable
private fun EvcPlusPaymentSection(
    totalAmount: Double,
    language: AppLanguage,
    isDark: Boolean,
    onOpenDialer: () -> Unit,
    onConfirmWhatsApp: () -> Unit
) {
    val ussdCode = EVCPlusHelper.generateUssdCode(totalAmount)

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isDark) Color(0xFF1B1715) else Color(0xFFFFFDF9)
        ),
        border = BorderStroke(1.dp, if (isDark) GoldBorderDark else GoldBorderLight)
    ) {
        Column(modifier = Modifier.padding(18.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(Color(0xFF0D47A1).copy(alpha = 0.15f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Dialpad,
                        contentDescription = null,
                        tint = Color(0xFF1976D2),
                        modifier = Modifier.size(22.dp)
                    )
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(
                        text = AppStrings.evcPlusTitle(language),
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = "Merchant Number: ${EVCPlusHelper.MERCHANT_PHONE_DISPLAY}",
                        fontSize = 11.sp,
                        color = if (isDark) GoldGlow else Color(0xFF8B6508)
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Highlighted USSD Dial Code
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                color = if (isDark) Color(0xFF26201C) else Color(0xFFF5EEE3),
                border = BorderStroke(1.5.dp, if (isDark) GoldGlow else Color(0xFFB8860B))
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "USSD PAYMENT CODE",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        letterSpacing = 1.sp
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = ussdCode,
                        fontSize = 22.sp,
                        fontWeight = FontWeight.ExtraBold,
                        fontFamily = FontFamily.Monospace,
                        color = if (isDark) GoldGlow else Color(0xFF8B6508)
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = AppStrings.evcPlusSubtitle(language),
                        fontSize = 11.sp,
                        textAlign = TextAlign.Center,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Spacer(modifier = Modifier.height(18.dp))

            // Direct Dialer Launch Button
            Button(
                onClick = onOpenDialer,
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFF0D47A1),
                    contentColor = Color.White
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .testTag("open_dialer_evc_button")
            ) {
                Icon(
                    imageVector = Icons.Default.Phone,
                    contentDescription = null,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = AppStrings.openDialer(language),
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Confirm on WhatsApp button
            Button(
                onClick = onConfirmWhatsApp,
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = WhatsAppGreen,
                    contentColor = Color.White
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
                    .testTag("confirm_order_whatsapp_button")
            ) {
                Text(
                    text = "💬 " + when (language) {
                        AppLanguage.ARABIC -> "تأكيد الطلب وإرسال الإشعار لواتساب الإدارة"
                        AppLanguage.SOMALI -> "Xaqiiji Dalabka adoo u diraya WhatsApp-ka"
                        AppLanguage.ENGLISH -> "Confirm Order via WhatsApp (0613679490)"
                    },
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@Composable
private fun DebitPayLaterSection(
    totalAmount: Double,
    language: AppLanguage,
    isDark: Boolean,
    fullName: String,
    onFullNameChange: (String) -> Unit,
    phoneNumber: String,
    onPhoneChange: (String) -> Unit,
    placeOrCity: String,
    onPlaceChange: (String) -> Unit,
    promisedDate: String,
    onPromisedDateChange: (String) -> Unit,
    frontIdUri: String?,
    onPickFrontId: () -> Unit,
    backIdUri: String?,
    onPickBackId: () -> Unit,
    pledgeChecked: Boolean,
    onPledgeChange: (Boolean) -> Unit,
    onSubmit: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isDark) Color(0xFF1B1715) else Color(0xFFFFFDF9)
        ),
        border = BorderStroke(1.dp, if (isDark) GoldBorderDark else GoldBorderLight)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // Header
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.Security,
                    contentDescription = null,
                    tint = if (isDark) GoldGlow else Color(0xFFB8860B),
                    modifier = Modifier.size(24.dp)
                )
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Text(
                        text = AppStrings.debitFormTitle(language),
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = AppStrings.debitOptionSubtitle(language),
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // 1. Full name as on National ID
            Text(
                text = AppStrings.fullNameNationalId(language),
                fontSize = 12.sp,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.onSurface
            )
            Spacer(modifier = Modifier.height(4.dp))
            OutlinedTextField(
                value = fullName,
                onValueChange = onFullNameChange,
                placeholder = { Text("e.g. Maryam Ali Hassan", fontSize = 13.sp) },
                leadingIcon = {
                    Icon(
                        imageVector = Icons.Default.Person,
                        contentDescription = null,
                        tint = if (isDark) GoldGlow else Color(0xFFB8860B)
                    )
                },
                singleLine = true,
                modifier = Modifier.fillMaxWidth().testTag("debit_full_name_input"),
                shape = RoundedCornerShape(12.dp)
            )

            Spacer(modifier = Modifier.height(12.dp))

            // 2. Real Country Phone Number
            Text(
                text = AppStrings.phoneNumber(language),
                fontSize = 12.sp,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.onSurface
            )
            Spacer(modifier = Modifier.height(4.dp))
            OutlinedTextField(
                value = phoneNumber,
                onValueChange = onPhoneChange,
                placeholder = { Text("e.g. +252 61 367 9490", fontSize = 13.sp) },
                leadingIcon = {
                    Icon(
                        imageVector = Icons.Default.Phone,
                        contentDescription = null,
                        tint = if (isDark) GoldGlow else Color(0xFFB8860B)
                    )
                },
                singleLine = true,
                modifier = Modifier.fillMaxWidth().testTag("debit_phone_input"),
                shape = RoundedCornerShape(12.dp)
            )

            Spacer(modifier = Modifier.height(12.dp))

            // 3. Place / Address / City
            Text(
                text = AppStrings.placeOrCity(language),
                fontSize = 12.sp,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.onSurface
            )
            Spacer(modifier = Modifier.height(4.dp))
            OutlinedTextField(
                value = placeOrCity,
                onValueChange = onPlaceChange,
                placeholder = { Text("e.g. Mogadishu, Hodan district", fontSize = 13.sp) },
                leadingIcon = {
                    Icon(
                        imageVector = Icons.Default.LocationOn,
                        contentDescription = null,
                        tint = if (isDark) GoldGlow else Color(0xFFB8860B)
                    )
                },
                singleLine = true,
                modifier = Modifier.fillMaxWidth().testTag("debit_place_input"),
                shape = RoundedCornerShape(12.dp)
            )

            Spacer(modifier = Modifier.height(12.dp))

            // 4. Promised payment date
            Text(
                text = AppStrings.promisedPaymentDate(language),
                fontSize = 12.sp,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.onSurface
            )
            Spacer(modifier = Modifier.height(4.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                listOf("7 Days", "14 Days", "30 Days").forEach { option ->
                    val isSelected = promisedDate.startsWith(option)
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = if (isSelected) Color(0xFFB8860B) else if (isDark) Color(0xFF26201C) else Color(0xFFF3ECE0),
                        modifier = Modifier
                            .weight(1f)
                            .clickable { onPromisedDateChange("$option (Approved terms)") }
                            .testTag("date_option_$option")
                    ) {
                        Text(
                            text = option,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurface,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.padding(vertical = 8.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // 5. Dual NIRA ID Document Upload (Forward & Backward)
            Text(
                text = "📄 NIRA National ID Documents (Both Sides Required):",
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = if (isDark) GoldGlow else Color(0xFF8B6508)
            )
            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Front ID Box
                Card(
                    modifier = Modifier
                        .weight(1f)
                        .height(120.dp)
                        .clickable { onPickFrontId() }
                        .testTag("pick_front_nira_id"),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = if (isDark) Color(0xFF241E1A) else Color(0xFFF7F1E7)
                    ),
                    border = BorderStroke(
                        1.dp,
                        if (frontIdUri != null) Color(0xFF2E7D32) else if (isDark) GoldBorderDark else GoldBorderLight
                    )
                ) {
                    Box(
                        modifier = Modifier.fillMaxSize(),
                        contentAlignment = Alignment.Center
                    ) {
                        if (frontIdUri != null) {
                            AsyncImage(
                                model = frontIdUri,
                                contentDescription = "Front ID",
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.fillMaxSize()
                            )
                            Surface(
                                shape = CircleShape,
                                color = Color(0xFF2E7D32),
                                modifier = Modifier
                                    .padding(6.dp)
                                    .align(Alignment.TopEnd)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Check,
                                    contentDescription = null,
                                    tint = Color.White,
                                    modifier = Modifier.size(16.dp).padding(2.dp)
                                )
                            }
                        } else {
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                modifier = Modifier.padding(8.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.AddPhotoAlternate,
                                    contentDescription = null,
                                    tint = if (isDark) GoldGlow else Color(0xFFB8860B),
                                    modifier = Modifier.size(28.dp)
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = AppStrings.uploadNiraFront(language),
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    textAlign = TextAlign.Center,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            }
                        }
                    }
                }

                // Back ID Box
                Card(
                    modifier = Modifier
                        .weight(1f)
                        .height(120.dp)
                        .clickable { onPickBackId() }
                        .testTag("pick_back_nira_id"),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = if (isDark) Color(0xFF241E1A) else Color(0xFFF7F1E7)
                    ),
                    border = BorderStroke(
                        1.dp,
                        if (backIdUri != null) Color(0xFF2E7D32) else if (isDark) GoldBorderDark else GoldBorderLight
                    )
                ) {
                    Box(
                        modifier = Modifier.fillMaxSize(),
                        contentAlignment = Alignment.Center
                    ) {
                        if (backIdUri != null) {
                            AsyncImage(
                                model = backIdUri,
                                contentDescription = "Back ID",
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.fillMaxSize()
                            )
                            Surface(
                                shape = CircleShape,
                                color = Color(0xFF2E7D32),
                                modifier = Modifier
                                    .padding(6.dp)
                                    .align(Alignment.TopEnd)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Check,
                                    contentDescription = null,
                                    tint = Color.White,
                                    modifier = Modifier.size(16.dp).padding(2.dp)
                                )
                            }
                        } else {
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                modifier = Modifier.padding(8.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.AddPhotoAlternate,
                                    contentDescription = null,
                                    tint = if (isDark) GoldGlow else Color(0xFFB8860B),
                                    modifier = Modifier.size(28.dp)
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = AppStrings.uploadNiraBack(language),
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    textAlign = TextAlign.Center,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Pledge Checkbox
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onPledgeChange(!pledgeChecked) }
                    .padding(vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Checkbox(
                    checked = pledgeChecked,
                    onCheckedChange = onPledgeChange,
                    colors = CheckboxDefaults.colors(
                        checkedColor = Color(0xFFB8860B)
                    ),
                    modifier = Modifier.testTag("debit_pledge_checkbox")
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = when (language) {
                        AppLanguage.ARABIC -> "أتعهد رسمياً بسداد كامل المبلغ في الموعد المحدد وأوافق على شروط متجر أم يوسف للجمال."
                        AppLanguage.SOMALI -> "Waxaan ballanqaadayaa inaan bixiyo lacagta oo dhan waqtigii loogu talagalay."
                        AppLanguage.ENGLISH -> "I solemnly pledge to repay the full debt on the agreed date under Umm Yousef store terms."
                    },
                    fontSize = 11.sp,
                    lineHeight = 16.sp,
                    color = MaterialTheme.colorScheme.onSurface
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            Text(
                text = "ℹ️ " + AppStrings.ownerReviewNotice(language),
                fontSize = 11.sp,
                lineHeight = 16.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Submit Button
            Button(
                onClick = onSubmit,
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = WhatsAppGreen,
                    contentColor = Color.White
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .testTag("submit_debit_request_button")
            ) {
                Text(
                    text = "📲 " + AppStrings.submitDebitToWhatsApp(language),
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center
                )
            }
        }
    }
}

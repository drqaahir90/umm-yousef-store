package com.example.ui.theme

import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

// Luxury Marketing Gold Accents
val GoldPrimary = Color(0xFFD4AF37)
val GoldLight = Color(0xFFF3E5AB)
val GoldGlow = Color(0xFFFFD700)
val GoldDark = Color(0xFF997D26)
val GoldMetallic = Color(0xFFC5A059)
val GoldBorderLight = Color(0xFFE6D7B9)
val GoldBorderDark = Color(0xFF6B5832)

// Light Theme: Soft Cream Marble Aesthetic
val CreamMarbleBackground = Color(0xFFFAF7F2)
val CreamMarbleSurface = Color(0xFFFFFDF9)
val CreamMarbleSurfaceVariant = Color(0xFFF4ECE1)
val CreamMarbleCardBorder = Color(0xFFE8DCC9)
val CharcoalTextPrimary = Color(0xFF231D18)
val CharcoalTextSecondary = Color(0xFF5C5248)
val RoseGoldSoft = Color(0xFFC78B78)

// Dark Theme: Deep Charcoal Marble Aesthetic
val CharcoalMarbleBackground = Color(0xFF131110)
val CharcoalMarbleSurface = Color(0xFF1B1715)
val CharcoalMarbleSurfaceVariant = Color(0xFF26211E)
val CharcoalMarbleCardBorder = Color(0xFF42372A)
val IvoryTextPrimary = Color(0xFFF9F5EF)
val IvoryTextSecondary = Color(0xFFBFAF9F)
val GlowingGoldGlow = Color(0xFFFFE082)

// Status Colors
val LuxuryGreen = Color(0xFF2E7D32)
val LuxuryRed = Color(0xFFC62828)
val WhatsAppGreen = Color(0xFF25D366)
val EVCBlue = Color(0xFF0D47A1)

// Gradients
val GoldFoilBrush = Brush.horizontalGradient(
    colors = listOf(
        Color(0xFFBF953F),
        Color(0xFFFCF6BA),
        Color(0xFFB38728),
        Color(0xFFFBF5B7),
        Color(0xFFAA771C)
    )
)

val DarkMarbleBrush = Brush.verticalGradient(
    colors = listOf(
        Color(0xFF1A1615),
        Color(0xFF12100E),
        Color(0xFF0D0B0A)
    )
)

val CreamMarbleBrush = Brush.verticalGradient(
    colors = listOf(
        Color(0xFFFFFDF9),
        Color(0xFFFAF6F0),
        Color(0xFFF5EFE6)
    )
)

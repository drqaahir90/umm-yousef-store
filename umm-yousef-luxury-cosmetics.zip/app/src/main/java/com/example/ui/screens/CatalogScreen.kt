package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.LocalOffer
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.model.AppLanguage
import com.example.model.Product
import com.example.model.ProductCategory
import com.example.ui.StoreViewModel
import com.example.ui.components.ProductCard
import com.example.ui.theme.GoldBorderDark
import com.example.ui.theme.GoldBorderLight
import com.example.ui.theme.GoldGlow
import com.example.ui.theme.GoldMetallic
import com.example.util.AppStrings

@Composable
fun CatalogScreen(
    viewModel: StoreViewModel,
    onProductClick: (Product) -> Unit,
    onOrderNowDirect: (Product) -> Unit
) {
    val products by viewModel.products.collectAsState()
    val language by viewModel.currentLanguage.collectAsState()
    val searchQuery by viewModel.searchQuery.collectAsState()
    val selectedCategory by viewModel.selectedCategory.collectAsState()
    val selectedAlphabet by viewModel.selectedAlphabet.collectAsState()

    val isDark = MaterialTheme.colorScheme.background.red < 0.2f

    // Filter products
    val filteredProducts = products.filter { product ->
        val matchesCategory = selectedCategory == ProductCategory.ALL || product.category == selectedCategory
        val matchesSearch = if (searchQuery.isBlank()) true else {
            product.nameEn.contains(searchQuery, ignoreCase = true) ||
            product.nameAr.contains(searchQuery, ignoreCase = true) ||
            product.nameSo.contains(searchQuery, ignoreCase = true) ||
            product.descriptionEn.contains(searchQuery, ignoreCase = true)
        }
        val alphabet = selectedAlphabet
        val matchesAlphabet = if (alphabet == null) true else {
            val name = product.localizedName(language)
            name.firstOrNull()?.equals(alphabet, ignoreCase = true) == true
        }
        matchesCategory && matchesSearch && matchesAlphabet
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // Luxury Banner with Promo Announcement
        HeroBanner(
            language = language,
            isDark = isDark,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
        )

        // Search Bar
        OutlinedTextField(
            value = searchQuery,
            onValueChange = { viewModel.setSearchQuery(it) },
            placeholder = {
                Text(
                    text = AppStrings.searchHint(language),
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                )
            },
            leadingIcon = {
                Icon(
                    imageVector = Icons.Default.Search,
                    contentDescription = "Search",
                    tint = if (isDark) GoldGlow else GoldMetallic
                )
            },
            trailingIcon = {
                if (searchQuery.isNotEmpty()) {
                    IconButton(onClick = { viewModel.setSearchQuery("") }) {
                        Icon(
                            imageVector = Icons.Default.Clear,
                            contentDescription = "Clear",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            },
            singleLine = true,
            shape = RoundedCornerShape(24.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = if (isDark) GoldGlow else GoldMetallic,
                unfocusedBorderColor = if (isDark) GoldBorderDark else GoldBorderLight,
                focusedContainerColor = if (isDark) Color(0xFF1B1715) else Color(0xFFFFFDF9),
                unfocusedContainerColor = if (isDark) Color(0xFF1B1715) else Color(0xFFFFFDF9)
            ),
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 4.dp)
                .testTag("catalog_search_input")
        )

        // Alphabet Quick Filter Bar (A-Z)
        AlphabetRibbon(
            selectedLetter = selectedAlphabet,
            onLetterSelect = { viewModel.setSelectedAlphabet(it) },
            language = language,
            isDark = isDark
        )

        // Category Filter Chips
        CategoryTabs(
            selectedCategory = selectedCategory,
            onSelect = { viewModel.setSelectedCategory(it) },
            language = language,
            isDark = isDark
        )

        Spacer(modifier = Modifier.height(4.dp))

        // Product Catalog Grid
        if (filteredProducts.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(32.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = "✨",
                        fontSize = 32.sp
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = when (language) {
                            AppLanguage.ARABIC -> "لم نجد منتجات مطابقة لبحثك. جربي فئة أخرى!"
                            AppLanguage.SOMALI -> "Lama helin wax natiijo ah. Dooro qayb kale!"
                            AppLanguage.ENGLISH -> "No cosmetics match your search. Try another category!"
                        },
                        fontSize = 14.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        textAlign = TextAlign.Center
                    )
                }
            }
        } else {
            LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                contentPadding = PaddingValues(start = 12.dp, end = 12.dp, top = 8.dp, bottom = 80.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.fillMaxSize().testTag("products_grid")
            ) {
                items(filteredProducts, key = { it.id }) { product ->
                    ProductCard(
                        product = product,
                        language = language,
                        onProductClick = { onProductClick(product) },
                        onAddToCart = { viewModel.addToCart(product, 1) },
                        onOrderNow = { onOrderNowDirect(product) }
                    )
                }
            }
        }
    }
}

@Composable
private fun HeroBanner(
    language: AppLanguage,
    isDark: Boolean,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .shadow(4.dp, RoundedCornerShape(16.dp)),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isDark) Color(0xFF221C18) else Color(0xFFFBF4E8)
        ),
        border = BorderStroke(1.dp, if (isDark) GoldBorderDark else GoldBorderLight)
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            // Official Flyer Banner Image
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(130.dp)
                    .clip(RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp))
            ) {
                Image(
                    painter = painterResource(id = R.drawable.banner_umm_yousef),
                    contentDescription = "Umm Yousef Beauty Official Banner",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
            }

            // Promotional ribbon underneath
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(
                        Brush.horizontalGradient(
                            if (isDark) {
                                listOf(Color(0xFF382D12), Color(0xFF4E3D18))
                            } else {
                                listOf(Color(0xFFF5E4C4), Color(0xFFFAF1DF))
                            }
                        )
                    )
                    .padding(horizontal = 12.dp, vertical = 7.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center
            ) {
                Icon(
                    imageVector = Icons.Default.LocalOffer,
                    contentDescription = "Promo",
                    tint = if (isDark) GoldGlow else Color(0xFF996515),
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = AppStrings.promoBanner(language),
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (isDark) GoldGlow else Color(0xFF6B470D),
                    textAlign = TextAlign.Center
                )
            }
        }
    }
}

@Composable
private fun AlphabetRibbon(
    selectedLetter: Char?,
    onLetterSelect: (Char?) -> Unit,
    language: AppLanguage,
    isDark: Boolean
) {
    val letters = if (language == AppLanguage.ARABIC) {
        listOf('أ', 'ب', 'ت', 'ث', 'ج', 'ح', 'خ', 'د', 'ر', 'ز', 'س', 'ش', 'ص', 'ع', 'ف', 'ق', 'ك', 'ل', 'م', 'ن', 'ه', 'و', 'ي')
    } else {
        ('A'..'Z').toList()
    }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .horizontalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 4.dp),
        horizontalArrangement = Arrangement.spacedBy(6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // "ALL" option
        Surface(
            shape = CircleShape,
            color = if (selectedLetter == null) {
                if (isDark) GoldGlow else Color(0xFFB8860B)
            } else {
                if (isDark) Color(0xFF221C18) else Color(0xFFF3ECE0)
            },
            border = BorderStroke(1.dp, if (isDark) GoldBorderDark else GoldBorderLight),
            modifier = Modifier
                .clickable { onLetterSelect(null) }
                .testTag("alphabet_filter_all")
        ) {
            Text(
                text = AppStrings.filterAllLetters(language),
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = if (selectedLetter == null) {
                    if (isDark) Color.Black else Color.White
                } else {
                    MaterialTheme.colorScheme.onSurface
                },
                modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
            )
        }

        // Each letter
        letters.forEach { letter ->
            val isSelected = selectedLetter == letter
            Surface(
                shape = CircleShape,
                color = if (isSelected) {
                    if (isDark) GoldGlow else Color(0xFFB8860B)
                } else {
                    if (isDark) Color(0xFF221C18) else Color(0xFFF3ECE0)
                },
                border = BorderStroke(1.dp, if (isDark) GoldBorderDark else GoldBorderLight),
                modifier = Modifier
                    .clickable { onLetterSelect(if (isSelected) null else letter) }
                    .testTag("alphabet_filter_$letter")
            ) {
                Text(
                    text = letter.toString(),
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (isSelected) {
                        if (isDark) Color.Black else Color.White
                    } else {
                        MaterialTheme.colorScheme.onSurface
                    },
                    modifier = Modifier.padding(horizontal = 9.dp, vertical = 5.dp)
                )
            }
        }
    }
}

@Composable
private fun CategoryTabs(
    selectedCategory: ProductCategory,
    onSelect: (ProductCategory) -> Unit,
    language: AppLanguage,
    isDark: Boolean
) {
    val categories = ProductCategory.entries

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .horizontalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 4.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        categories.forEach { category ->
            val isSelected = selectedCategory == category
            Surface(
                shape = RoundedCornerShape(20.dp),
                color = if (isSelected) {
                    if (isDark) GoldGlow else Color(0xFFB8860B)
                } else {
                    if (isDark) Color(0xFF1F1A17) else Color(0xFFF5EEE3)
                },
                border = BorderStroke(
                    1.dp,
                    if (isSelected) Color.Transparent else if (isDark) GoldBorderDark else GoldBorderLight
                ),
                modifier = Modifier
                    .clickable { onSelect(category) }
                    .testTag("category_tab_${category.id}")
            ) {
                Text(
                    text = AppStrings.categoryName(category, language),
                    fontSize = 12.sp,
                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                    color = if (isSelected) {
                        if (isDark) Color.Black else Color.White
                    } else {
                        MaterialTheme.colorScheme.onSurface
                    },
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 7.dp)
                )
            }
        }
    }
}

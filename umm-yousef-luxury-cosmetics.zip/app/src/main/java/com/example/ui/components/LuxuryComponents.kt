package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Translate
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.example.model.AppLanguage
import com.example.model.AppThemeMode
import com.example.model.Product
import androidx.compose.ui.graphics.RectangleShape
import com.example.ui.theme.GoldDark
import com.example.ui.theme.GoldBorderDark
import com.example.ui.theme.GoldBorderLight
import com.example.ui.theme.GoldFoilBrush
import com.example.ui.theme.GoldGlow
import com.example.ui.theme.GoldMetallic
import com.example.ui.theme.GoldPrimary
import com.example.ui.theme.RoseGoldSoft
import com.example.util.AppStrings

@Composable
fun LuxuryTopBar(
    language: AppLanguage,
    themeMode: AppThemeMode,
    cartItemCount: Int,
    onLanguageClick: () -> Unit,
    onThemeClick: () -> Unit,
    onCartClick: () -> Unit,
    onOwnerClick: () -> Unit,
    onCustomerProfileClick: () -> Unit,
    customerName: String
) {
    val isDark = MaterialTheme.colorScheme.background.red < 0.2f

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(
                Brush.verticalGradient(
                    colors = if (isDark) {
                        listOf(Color(0xFF1F1A17), Color(0xFF14110F))
                    } else {
                        listOf(Color(0xFFFFFDF9), Color(0xFFF9F5EC))
                    }
                )
            )
            .border(
                width = 1.dp,
                brush = Brush.horizontalGradient(
                    listOf(
                        Color.Transparent,
                        if (isDark) GoldBorderDark else GoldBorderLight,
                        Color.Transparent
                    )
                ),
                shape = RectangleShape
            )
            .padding(horizontal = 16.dp, vertical = 10.dp)
    ) {
        // Upper action bar: Customer tag, Language, Theme, Owner PIN, Cart
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Customer Greeting / WhatsApp Link
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .clip(RoundedCornerShape(20.dp))
                    .background(if (isDark) Color(0xFF26211D) else Color(0xFFF2E9DC))
                    .clickable { onCustomerProfileClick() }
                    .padding(horizontal = 10.dp, vertical = 4.dp)
                    .testTag("customer_profile_button")
            ) {
                Box(
                    modifier = Modifier
                        .size(8.dp)
                        .clip(CircleShape)
                        .background(Color(0xFF25D366))
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = if (customerName.isNotBlank()) customerName else "0613679490",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.primary
                )
            }

            // Quick actions
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                // Language switch
                IconButton(
                    onClick = onLanguageClick,
                    modifier = Modifier.size(38.dp).testTag("language_switch_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Translate,
                        contentDescription = "Language",
                        tint = if (isDark) GoldGlow else GoldMetallic,
                        modifier = Modifier.size(20.dp)
                    )
                }

                // Theme switch
                IconButton(
                    onClick = onThemeClick,
                    modifier = Modifier.size(38.dp).testTag("theme_switch_button")
                ) {
                    Icon(
                        imageVector = if (isDark) Icons.Default.LightMode else Icons.Default.DarkMode,
                        contentDescription = "Theme",
                        tint = if (isDark) GoldGlow else GoldMetallic,
                        modifier = Modifier.size(20.dp)
                    )
                }

                // Owner Admin Portal
                IconButton(
                    onClick = onOwnerClick,
                    modifier = Modifier.size(38.dp).testTag("owner_portal_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.AdminPanelSettings,
                        contentDescription = "Owner Portal",
                        tint = if (isDark) GoldGlow else GoldMetallic,
                        modifier = Modifier.size(20.dp)
                    )
                }

                // Cart / Basket
                IconButton(
                    onClick = onCartClick,
                    modifier = Modifier.size(38.dp).testTag("cart_button")
                ) {
                    BadgedBox(
                        badge = {
                            if (cartItemCount > 0) {
                                Badge(
                                    containerColor = Color(0xFFB8860B),
                                    contentColor = Color.White
                                ) {
                                    Text(
                                        text = cartItemCount.toString(),
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    ) {
                        Icon(
                            imageVector = Icons.Default.ShoppingBag,
                            contentDescription = "Shopping Basket",
                            tint = if (isDark) GoldGlow else GoldMetallic,
                            modifier = Modifier.size(22.dp)
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        // Centerpiece: Brand Name and Calligraphy Slogan
        Column(
            modifier = Modifier.fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Botanical crown ornament
            Text(
                text = "✨ ❀ ┈┈┈┈┈┈┈┈┈┈┈┈┈ ❀ ✨",
                fontSize = 11.sp,
                color = if (isDark) GoldGlow.copy(alpha = 0.7f) else GoldMetallic.copy(alpha = 0.7f),
                letterSpacing = 1.sp
            )

            // Brand Title
            Text(
                text = AppStrings.brandName(language),
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Serif,
                color = if (isDark) GoldGlow else Color(0xFF6B4E12),
                textAlign = TextAlign.Center
            )

            Text(
                text = "UMM YOUSEF ONLINE SHOPPING",
                fontSize = 9.sp,
                fontWeight = FontWeight.Medium,
                letterSpacing = 2.5.sp,
                color = if (isDark) Color(0xFFD5C8BD) else Color(0xFF8C7A6B),
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(4.dp))

            // Prominent Arabic Calligraphy Slogan (as requested by user!)
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = if (isDark) Color(0xFF2B231D) else Color(0xFFF9F1E2),
                border = BorderStroke(
                    1.dp,
                    if (isDark) GoldBorderDark else GoldBorderLight
                ),
                modifier = Modifier.padding(horizontal = 12.dp)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    Text(
                        text = "🌿 ",
                        fontSize = 13.sp
                    )
                    Text(
                        text = AppStrings.SLOGAN_AR,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Serif,
                        color = if (isDark) GoldGlow else Color(0xFF8B6508),
                        textAlign = TextAlign.Center
                    )
                    Text(
                        text = " 🌿",
                        fontSize = 13.sp
                    )
                }
            }

            if (language != AppLanguage.ARABIC) {
                Text(
                    text = AppStrings.slogan(language),
                    fontSize = 10.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(top = 2.dp)
                )
            }
        }
    }
}

@Composable
fun ProductCard(
    product: Product,
    language: AppLanguage,
    onProductClick: () -> Unit,
    onAddToCart: () -> Unit,
    onOrderNow: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val isDark = MaterialTheme.colorScheme.background.red < 0.2f

    Card(
        modifier = modifier
            .fillMaxWidth()
            .clickable { onProductClick() }
            .shadow(
                elevation = if (isDark) 4.dp else 2.dp,
                shape = RoundedCornerShape(16.dp)
            )
            .testTag("product_card_${product.id}"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isDark) Color(0xFF1C1815) else Color(0xFFFFFDF9)
        ),
        border = BorderStroke(
            1.dp,
            if (isDark) GoldBorderDark.copy(alpha = 0.5f) else GoldBorderLight
        )
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            // Product Image Container with Badges
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(180.dp)
                    .background(if (isDark) Color(0xFF14110F) else Color(0xFFF7F2E9))
            ) {
                ProductImage(
                    product = product,
                    modifier = Modifier.fillMaxWidth().height(180.dp)
                )

                // Discount Badge (-25%)
                Surface(
                    modifier = Modifier
                        .padding(8.dp)
                        .align(Alignment.TopStart),
                    shape = RoundedCornerShape(8.dp),
                    color = Color(0xFFB8860B).copy(alpha = 0.95f)
                ) {
                    Text(
                        text = "−25% OFF",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        modifier = Modifier.padding(horizontal = 7.dp, vertical = 3.dp)
                    )
                }

                // Volume / Size Tag
                Surface(
                    modifier = Modifier
                        .padding(8.dp)
                        .align(Alignment.BottomEnd),
                    shape = RoundedCornerShape(8.dp),
                    color = Color.Black.copy(alpha = 0.65f)
                ) {
                    Text(
                        text = product.volumeOrSize,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Medium,
                        color = Color.White,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
            }

            // Details
            Column(modifier = Modifier.padding(12.dp)) {
                // Category & Rating
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = AppStrings.categoryName(product.category, language).uppercase(),
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isDark) GoldGlow else GoldDark,
                        letterSpacing = 0.5.sp
                    )

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Star,
                            contentDescription = "Rating",
                            tint = Color(0xFFFFB300),
                            modifier = Modifier.size(13.dp)
                        )
                        Spacer(modifier = Modifier.width(3.dp))
                        Text(
                            text = String.format(java.util.Locale.US, "%.1f", product.rating),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }

                Spacer(modifier = Modifier.height(4.dp))

                // Name
                Text(
                    text = product.localizedName(language),
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onSurface,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                    lineHeight = 18.sp
                )

                Spacer(modifier = Modifier.height(8.dp))

                // Price Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.Bottom,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        if (product.originalPriceUsd != null) {
                            Text(
                                text = "$${String.format(java.util.Locale.US, "%.2f", product.originalPriceUsd)}",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f),
                                textDecoration = TextDecoration.LineThrough
                            )
                        }
                        Text(
                            text = "$${String.format(java.util.Locale.US, "%.2f", product.priceUsd)}",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (isDark) GoldGlow else Color(0xFF8B6508)
                        )
                    }

                    // Action buttons
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        // Quick Add to Basket
                        Surface(
                            shape = CircleShape,
                            color = if (isDark) Color(0xFF2C241E) else Color(0xFFF3ECE0),
                            border = BorderStroke(1.dp, if (isDark) GoldBorderDark else GoldBorderLight),
                            modifier = Modifier
                                .size(34.dp)
                                .clickable { onAddToCart() }
                                .testTag("quick_add_cart_${product.id}")
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Default.ShoppingBag,
                                    contentDescription = "Add",
                                    tint = if (isDark) GoldGlow else GoldDark,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }

                        // Order Now button
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = Color(0xFFB8860B),
                            modifier = Modifier
                                .height(34.dp)
                                .clickable { onOrderNow() }
                                .testTag("quick_order_now_${product.id}")
                        ) {
                            Box(
                                modifier = Modifier.padding(horizontal = 10.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = AppStrings.orderNow(language),
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ProductImage(
    product: Product,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current

    if (product.customImageUri != null) {
        AsyncImage(
            model = ImageRequest.Builder(context)
                .data(product.customImageUri)
                .crossfade(true)
                .build(),
            contentDescription = product.nameEn,
            contentScale = ContentScale.Crop,
            modifier = modifier
        )
    } else {
        // Resolve drawable resource by name
        val resId = context.resources.getIdentifier(
            product.imageResName,
            "drawable",
            context.packageName
        )
        if (resId != 0) {
            Image(
                painter = painterResource(id = resId),
                contentDescription = product.nameEn,
                contentScale = ContentScale.Crop,
                modifier = modifier
            )
        } else {
            // Fallback to launcher icon or placeholder
            Image(
                painter = painterResource(id = com.example.R.drawable.app_launcher_icon),
                contentDescription = product.nameEn,
                contentScale = ContentScale.Fit,
                modifier = modifier.padding(16.dp)
            )
        }
    }
}

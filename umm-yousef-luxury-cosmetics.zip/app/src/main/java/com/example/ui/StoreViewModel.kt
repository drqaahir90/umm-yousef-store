package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import com.example.data.StoreRepository
import com.example.model.AppLanguage
import com.example.model.AppThemeMode
import com.example.model.CartItem
import com.example.model.CustomerProfile
import com.example.model.DebitRequest
import com.example.model.DebitStatus
import com.example.model.Product
import com.example.model.ProductCategory
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

enum class StoreScreen {
    CATALOG,
    PRODUCT_DETAIL,
    BASKET,
    CHECKOUT,
    OWNER_PORTAL,
    CUSTOMER_ONBOARDING
}

class StoreViewModel(application: Application) : AndroidViewModel(application) {
    val repository = StoreRepository(application.applicationContext)

    val products: StateFlow<List<Product>> = repository.products
    val cart: StateFlow<List<CartItem>> = repository.cart
    val debitRequests: StateFlow<List<DebitRequest>> = repository.debitRequests
    val currentLanguage: StateFlow<AppLanguage> = repository.currentLanguage
    val currentTheme: StateFlow<AppThemeMode> = repository.currentTheme
    val customerProfile: StateFlow<CustomerProfile> = repository.customerProfile

    private val _currentScreen = MutableStateFlow(StoreScreen.CATALOG)
    val currentScreen: StateFlow<StoreScreen> = _currentScreen.asStateFlow()

    private val _selectedProduct = MutableStateFlow<Product?>(null)
    val selectedProduct: StateFlow<Product?> = _selectedProduct.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _selectedCategory = MutableStateFlow(ProductCategory.ALL)
    val selectedCategory: StateFlow<ProductCategory> = _selectedCategory.asStateFlow()

    private val _selectedAlphabet = MutableStateFlow<Char?>(null)
    val selectedAlphabet: StateFlow<Char?> = _selectedAlphabet.asStateFlow()

    private val _discountApplied = MutableStateFlow(true) // 25% discount promo enabled by default
    val discountApplied: StateFlow<Boolean> = _discountApplied.asStateFlow()

    fun navigateTo(screen: StoreScreen) {
        _currentScreen.value = screen
    }

    fun openProductDetail(product: Product) {
        _selectedProduct.value = product
        _currentScreen.value = StoreScreen.PRODUCT_DETAIL
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
        if (query.isNotBlank()) {
            _selectedAlphabet.value = null
        }
    }

    fun setSelectedCategory(category: ProductCategory) {
        _selectedCategory.value = category
    }

    fun setSelectedAlphabet(letter: Char?) {
        _selectedAlphabet.value = letter
        if (letter != null) {
            _searchQuery.value = ""
        }
    }

    fun toggleDiscount() {
        _discountApplied.value = !_discountApplied.value
    }

    fun setLanguage(lang: AppLanguage) {
        repository.setLanguage(lang)
    }

    fun setTheme(theme: AppThemeMode) {
        repository.setTheme(theme)
    }

    fun addToCart(product: Product, quantity: Int = 1) {
        repository.addToCart(product, quantity)
    }

    fun updateCartQuantity(productId: String, quantity: Int) {
        repository.updateCartQuantity(productId, quantity)
    }

    fun removeFromCart(productId: String) {
        repository.removeFromCart(productId)
    }

    fun clearCart() {
        repository.clearCart()
    }

    fun saveCustomerProfile(name: String, phone: String, city: String) {
        repository.saveCustomerProfile(name, phone, city)
    }

    fun addProduct(product: Product) {
        repository.addProduct(product)
    }

    fun updateProduct(product: Product) {
        repository.updateProduct(product)
    }

    fun deleteProduct(productId: String) {
        repository.deleteProduct(productId)
    }

    fun submitDebitRequest(
        fullName: String,
        phone: String,
        place: String,
        promisedDate: String,
        frontIdUri: String?,
        backIdUri: String?,
        itemsSummary: String,
        totalAmount: Double
    ): DebitRequest {
        return repository.submitDebitRequest(
            fullName = fullName,
            phone = phone,
            place = place,
            promisedDate = promisedDate,
            frontIdUri = frontIdUri,
            backIdUri = backIdUri,
            itemsSummary = itemsSummary,
            totalAmount = totalAmount
        )
    }

    fun updateDebitStatus(requestId: String, status: DebitStatus, notes: String = "") {
        repository.updateDebitStatus(requestId, status, notes)
    }

    fun calculateSubtotal(): Double {
        return cart.value.sumOf { it.subtotal }
    }

    fun calculateTotal(): Double {
        val subtotal = calculateSubtotal()
        return if (_discountApplied.value) {
            subtotal * 0.75 // 25% discount
        } else {
            subtotal
        }
    }

    fun getCartItemsSummary(): String {
        return cart.value.joinToString("\n") {
            "• ${it.product.nameEn} (x${it.quantity}) - $${String.format(java.util.Locale.US, "%.2f", it.subtotal)}"
        }
    }
}

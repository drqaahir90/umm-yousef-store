package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import com.example.model.AppThemeMode

private val LuxuryDarkColorScheme = darkColorScheme(
    primary = GoldGlow,
    onPrimary = CharcoalMarbleBackground,
    primaryContainer = Color(0xFF4A3C13),
    onPrimaryContainer = GoldLight,
    secondary = RoseGoldSoft,
    onSecondary = CharcoalMarbleBackground,
    secondaryContainer = Color(0xFF3E2822),
    onSecondaryContainer = Color(0xFFFFDBCF),
    background = CharcoalMarbleBackground,
    onBackground = IvoryTextPrimary,
    surface = CharcoalMarbleSurface,
    onSurface = IvoryTextPrimary,
    surfaceVariant = CharcoalMarbleSurfaceVariant,
    onSurfaceVariant = IvoryTextSecondary,
    outline = GoldBorderDark,
    outlineVariant = Color(0xFF2C241C)
)

private val LuxuryLightColorScheme = lightColorScheme(
    primary = GoldMetallic,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFFBF4E4),
    onPrimaryContainer = GoldDark,
    secondary = RoseGoldSoft,
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFFFEDE6),
    onSecondaryContainer = Color(0xFF4E2219),
    background = CreamMarbleBackground,
    onBackground = CharcoalTextPrimary,
    surface = CreamMarbleSurface,
    onSurface = CharcoalTextPrimary,
    surfaceVariant = CreamMarbleSurfaceVariant,
    onSurfaceVariant = CharcoalTextSecondary,
    outline = GoldBorderLight,
    outlineVariant = Color(0xFFEDE2CF)
)

@Composable
fun UmmYousefTheme(
    themeMode: AppThemeMode = AppThemeMode.SYSTEM,
    content: @Composable () -> Unit
) {
    val darkTheme = when (themeMode) {
        AppThemeMode.LIGHT -> false
        AppThemeMode.DARK -> true
        AppThemeMode.SYSTEM -> isSystemInDarkTheme()
    }

    val colorScheme = if (darkTheme) LuxuryDarkColorScheme else LuxuryLightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}

package com.example.ui.screens

import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.RequestQuote
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.model.AppLanguage
import com.example.model.DebitRequest
import com.example.model.DebitStatus
import com.example.model.Product
import com.example.model.ProductCategory
import com.example.ui.StoreViewModel
import com.example.ui.components.ProductImage
import com.example.ui.theme.GoldBorderDark
import com.example.ui.theme.GoldBorderLight
import com.example.ui.theme.GoldGlow
import com.example.ui.theme.GoldMetallic
import com.example.ui.theme.WhatsAppGreen
import com.example.util.AiCopywriter
import com.example.util.AppStrings
import com.example.util.WhatsAppHelper
import java.util.UUID

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun OwnerPortalScreen(
    viewModel: StoreViewModel,
    onBackClick: () -> Unit
) {
    val context = LocalContext.current
    val language by viewModel.currentLanguage.collectAsState()
    val products by viewModel.products.collectAsState()
    val debitRequests by viewModel.debitRequests.collectAsState()
    val isDark = MaterialTheme.colorScheme.background.red < 0.2f

    var isUnlocked by remember { mutableStateOf(false) }
    var enteredPin by remember { mutableStateOf("") }
    var pinError by remember { mutableStateOf(false) }

    // Owner Tabs: 0: Products, 1: AI Assistant, 2: Debit Requests
    var selectedTab by remember { mutableIntStateOf(0) }

    // Dialogs
    var showAddProductDialog by remember { mutableStateOf(false) }
    var editingProduct by remember { mutableStateOf<Product?>(null) }
    var inspectingDebitRequest by remember { mutableStateOf<DebitRequest?>(null) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = AppStrings.ownerPortal(language),
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                },
                navigationIcon = {
                    IconButton(
                        onClick = onBackClick,
                        modifier = Modifier.testTag("owner_back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = if (isDark) GoldGlow else GoldMetallic
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                )
            )
        }
    ) { innerPadding ->
        if (!isUnlocked) {
            // PIN Lock Screen
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .background(MaterialTheme.colorScheme.background),
                contentAlignment = Alignment.Center
            ) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth(0.9f)
                        .padding(16.dp),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = if (isDark) Color(0xFF1E1916) else Color(0xFFFFFDF9)
                    ),
                    border = BorderStroke(1.dp, if (isDark) GoldBorderDark else GoldBorderLight)
                ) {
                    Column(
                        modifier = Modifier.padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Surface(
                            shape = CircleShape,
                            color = if (isDark) Color(0xFF332918) else Color(0xFFFAF2E4),
                            modifier = Modifier.size(60.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Default.Lock,
                                    contentDescription = null,
                                    tint = if (isDark) GoldGlow else Color(0xFFB8860B),
                                    modifier = Modifier.size(30.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        Text(
                            text = AppStrings.ownerPortal(language),
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )

                        Text(
                            text = AppStrings.enterPin(language),
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        Spacer(modifier = Modifier.height(16.dp))

                        OutlinedTextField(
                            value = enteredPin,
                            onValueChange = {
                                enteredPin = it
                                pinError = false
                            },
                            visualTransformation = PasswordVisualTransformation(),
                            placeholder = { Text("Default PIN: 79490", fontSize = 12.sp) },
                            isError = pinError,
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth().testTag("owner_pin_input"),
                            shape = RoundedCornerShape(12.dp)
                        )

                        if (pinError) {
                            Text(
                                text = "Invalid PIN. Default is 79490",
                                color = MaterialTheme.colorScheme.error,
                                fontSize = 11.sp,
                                modifier = Modifier.padding(top = 4.dp)
                            )
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        Button(
                            onClick = {
                                if (enteredPin == AppStrings.OWNER_DEFAULT_PIN || enteredPin == "0613679490") {
                                    isUnlocked = true
                                    pinError = false
                                } else {
                                    pinError = true
                                }
                            },
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Color(0xFFB8860B),
                                contentColor = Color.White
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                                .testTag("unlock_owner_button")
                        ) {
                            Text(
                                text = "Unlock Portal (دخول الإدارة)",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        } else {
            // Unlocked Owner Workspace
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .background(MaterialTheme.colorScheme.background)
            ) {
                // Owner Navigation Tabs
                TabRow(
                    selectedTabIndex = selectedTab,
                    containerColor = if (isDark) Color(0xFF1B1715) else Color(0xFFF5EEE3),
                    contentColor = if (isDark) GoldGlow else Color(0xFFB8860B),
                    indicator = { tabPositions ->
                        TabRowDefaults.SecondaryIndicator(
                            Modifier.tabIndicatorOffset(tabPositions[selectedTab]),
                            color = if (isDark) GoldGlow else Color(0xFFB8860B)
                        )
                    }
                ) {
                    Tab(
                        selected = selectedTab == 0,
                        onClick = { selectedTab = 0 },
                        text = { Text("Inventory (${products.size})", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                        icon = { Icon(Icons.Default.Inventory2, contentDescription = null, modifier = Modifier.size(16.dp)) },
                        modifier = Modifier.testTag("owner_tab_inventory")
                    )
                    Tab(
                        selected = selectedTab == 1,
                        onClick = { selectedTab = 1 },
                        text = { Text("AI Writer", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                        icon = { Icon(Icons.Default.AutoAwesome, contentDescription = null, modifier = Modifier.size(16.dp)) },
                        modifier = Modifier.testTag("owner_tab_ai_writer")
                    )
                    Tab(
                        selected = selectedTab == 2,
                        onClick = { selectedTab = 2 },
                        text = { Text("Debits (${debitRequests.size})", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                        icon = { Icon(Icons.Default.RequestQuote, contentDescription = null, modifier = Modifier.size(16.dp)) },
                        modifier = Modifier.testTag("owner_tab_debits")
                    )
                }

                when (selectedTab) {
                    0 -> InventoryTab(
                        products = products,
                        language = language,
                        isDark = isDark,
                        onAddNewProduct = { showAddProductDialog = true },
                        onEditProduct = { editingProduct = it },
                        onDeleteProduct = { viewModel.deleteProduct(it.id) }
                    )
                    1 -> AiWriterTab(
                        language = language,
                        isDark = isDark,
                        onAddGeneratedProduct = { generatedProduct ->
                            viewModel.addProduct(generatedProduct)
                            Toast.makeText(context, "Added ${generatedProduct.nameEn} to catalog!", Toast.LENGTH_SHORT).show()
                            selectedTab = 0
                        }
                    )
                    2 -> DebitRequestsTab(
                        requests = debitRequests,
                        language = language,
                        isDark = isDark,
                        onInspect = { inspectingDebitRequest = it },
                        onApprove = { req ->
                            viewModel.updateDebitStatus(req.id, DebitStatus.APPROVED, "Approved by Owner")
                            val notifyText = "مرحباً ${req.fullName}، تمت الموافقة على طلب الشراء بالآجل (Deyn) بمبلغ $${req.totalAmountUsd} من متجر أم يوسف للجمال. موعد السداد: ${req.promisedPaymentDate}. شكراً لثقتكم!"
                            WhatsAppHelper.openWhatsAppMessage(context, notifyText)
                        },
                        onReject = { req ->
                            viewModel.updateDebitStatus(req.id, DebitStatus.REJECTED, "Rejected by Owner")
                            val notifyText = "مرحباً ${req.fullName}، نعتذر عن قبول طلب الشراء بالآجل في الوقت الحالي من متجر أم يوسف للجمال. يمكنك الشراء المباشر عبر EVC Plus. شكراً لتفهمكم."
                            WhatsAppHelper.openWhatsAppMessage(context, notifyText)
                        }
                    )
                }
            }
        }
    }

    // Add Product Modal
    if (showAddProductDialog) {
        ProductFormDialog(
            product = null,
            language = language,
            isDark = isDark,
            onDismiss = { showAddProductDialog = false },
            onSave = { newProd ->
                viewModel.addProduct(newProd)
                showAddProductDialog = false
            }
        )
    }

    // Edit Product Modal
    if (editingProduct != null) {
        ProductFormDialog(
            product = editingProduct,
            language = language,
            isDark = isDark,
            onDismiss = { editingProduct = null },
            onSave = { updatedProd ->
                viewModel.updateProduct(updatedProd)
                editingProduct = null
            }
        )
    }

    // Inspect Debit Request Modal (View full NIRA ID documents)
    if (inspectingDebitRequest != null) {
        InspectDebitModal(
            request = inspectingDebitRequest!!,
            language = language,
            isDark = isDark,
            onDismiss = { inspectingDebitRequest = null }
        )
    }
}

@Composable
private fun InventoryTab(
    products: List<Product>,
    language: AppLanguage,
    isDark: Boolean,
    onAddNewProduct: () -> Unit,
    onEditProduct: (Product) -> Unit,
    onDeleteProduct: (Product) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Button(
            onClick = onAddNewProduct,
            shape = RoundedCornerShape(12.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFB8860B)),
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp)
                .testTag("owner_add_new_product_button")
        ) {
            Icon(Icons.Default.Add, contentDescription = null)
            Spacer(modifier = Modifier.width(8.dp))
            Text(AppStrings.addNewProduct(language), fontWeight = FontWeight.Bold)
        }

        Spacer(modifier = Modifier.height(12.dp))

        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(10.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            items(products, key = { it.id }) { product ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = if (isDark) Color(0xFF1F1A17) else Color(0xFFFFFDF9)
                    ),
                    border = BorderStroke(1.dp, if (isDark) GoldBorderDark else GoldBorderLight)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(56.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (isDark) Color(0xFF14110F) else Color(0xFFF7F2E9))
                        ) {
                            ProductImage(product = product, modifier = Modifier.fillMaxSize())
                        }

                        Spacer(modifier = Modifier.width(10.dp))

                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = product.nameEn,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                maxLines = 1,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = product.nameAr,
                                fontSize = 11.sp,
                                maxLines = 1,
                                color = if (isDark) GoldGlow else Color(0xFF8B6508)
                            )
                            Text(
                                text = "$${String.format(java.util.Locale.US, "%.2f", product.priceUsd)} • ${product.volumeOrSize}",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }

                        IconButton(
                            onClick = { onEditProduct(product) },
                            modifier = Modifier.size(36.dp).testTag("edit_product_${product.id}")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Edit,
                                contentDescription = "Edit",
                                tint = if (isDark) GoldGlow else Color(0xFFB8860B),
                                modifier = Modifier.size(18.dp)
                            )
                        }

                        IconButton(
                            onClick = { onDeleteProduct(product) },
                            modifier = Modifier.size(36.dp).testTag("delete_product_${product.id}")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Delete,
                                contentDescription = "Delete",
                                tint = MaterialTheme.colorScheme.error,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun AiWriterTab(
    language: AppLanguage,
    isDark: Boolean,
    onAddGeneratedProduct: (Product) -> Unit
) {
    var productNameInput by remember { mutableStateOf("Royal Jasmine & Saffron Glow Serum") }
    var selectedCategory by remember { mutableStateOf(ProductCategory.SKINCARE) }
    var keyIngredientInput by remember { mutableStateOf("Kashmiri Saffron & Cold-Pressed Rosehip") }
    var priceInput by remember { mutableStateOf("32.00") }
    var volumeInput by remember { mutableStateOf("50 ml") }

    var generatedCopy by remember {
        mutableStateOf(
            AiCopywriter.generateProductCopy(
                productName = "Royal Jasmine & Saffron Glow Serum",
                category = ProductCategory.SKINCARE,
                keyIngredientsOrFeature = "Kashmiri Saffron & Cold-Pressed Rosehip"
            )
        )
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(
                containerColor = if (isDark) Color(0xFF241D18) else Color(0xFFFAF3E6)
            ),
            border = BorderStroke(1.dp, if (isDark) GoldBorderDark else GoldBorderLight)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.AutoAwesome,
                        contentDescription = null,
                        tint = if (isDark) GoldGlow else Color(0xFFB8860B),
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = AppStrings.aiCopywriter(language),
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = productNameInput,
                    onValueChange = { productNameInput = it },
                    label = { Text("Product Name") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("ai_product_name_input"),
                    shape = RoundedCornerShape(12.dp)
                )

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = keyIngredientInput,
                    onValueChange = { keyIngredientInput = it },
                    label = { Text("Key Ingredients / Star Feature") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("ai_key_ingredient_input"),
                    shape = RoundedCornerShape(12.dp)
                )

                Spacer(modifier = Modifier.height(12.dp))

                Button(
                    onClick = {
                        generatedCopy = AiCopywriter.generateProductCopy(
                            productName = productNameInput,
                            category = selectedCategory,
                            keyIngredientsOrFeature = keyIngredientInput
                        )
                    },
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFB8860B)),
                    modifier = Modifier.fillMaxWidth().height(48.dp).testTag("ai_generate_button")
                ) {
                    Icon(Icons.Default.AutoAwesome, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(AppStrings.generateDescriptionWithAi(language), fontWeight = FontWeight.Bold)
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Generated Output Previews
        Text(
            text = "AI Generated Arabic Luxury Copy:",
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold,
            color = if (isDark) GoldGlow else Color(0xFF8B6508)
        )
        Spacer(modifier = Modifier.height(4.dp))
        Surface(
            shape = RoundedCornerShape(10.dp),
            color = if (isDark) Color(0xFF1E1916) else Color(0xFFFFFDF9),
            border = BorderStroke(1.dp, if (isDark) GoldBorderDark else GoldBorderLight),
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(
                text = generatedCopy.descriptionAr,
                fontSize = 12.sp,
                lineHeight = 18.sp,
                modifier = Modifier.padding(12.dp)
            )
        }

        Spacer(modifier = Modifier.height(10.dp))

        Text(
            text = "AI Generated English Copy:",
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold,
            color = if (isDark) GoldGlow else Color(0xFF8B6508)
        )
        Spacer(modifier = Modifier.height(4.dp))
        Surface(
            shape = RoundedCornerShape(10.dp),
            color = if (isDark) Color(0xFF1E1916) else Color(0xFFFFFDF9),
            border = BorderStroke(1.dp, if (isDark) GoldBorderDark else GoldBorderLight),
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(
                text = generatedCopy.descriptionEn,
                fontSize = 12.sp,
                lineHeight = 18.sp,
                modifier = Modifier.padding(12.dp)
            )
        }

        Spacer(modifier = Modifier.height(14.dp))

        // 1-tap Create and Add Product to Store
        Button(
            onClick = {
                val price = priceInput.toDoubleOrNull() ?: 25.0
                val product = Product(
                    id = "prod_" + UUID.randomUUID().toString().take(6),
                    nameEn = productNameInput,
                    nameAr = "مستحضر $productNameInput الملكي",
                    nameSo = "Badeecada $productNameInput ee Umm Yousef",
                    category = selectedCategory,
                    priceUsd = price,
                    originalPriceUsd = price * 1.3,
                    imageResName = "item_gold_serum",
                    volumeOrSize = volumeInput,
                    descriptionEn = generatedCopy.descriptionEn,
                    descriptionAr = generatedCopy.descriptionAr,
                    descriptionSo = generatedCopy.descriptionSo,
                    keyBenefitsEn = generatedCopy.benefitsEn,
                    keyBenefitsAr = generatedCopy.benefitsAr,
                    keyBenefitsSo = generatedCopy.benefitsSo,
                    ingredientsEn = generatedCopy.ingredientsEn,
                    ingredientsAr = generatedCopy.ingredientsAr,
                    ingredientsSo = generatedCopy.ingredientsSo,
                    howToUseEn = generatedCopy.howToUseEn,
                    howToUseAr = generatedCopy.howToUseAr,
                    howToUseSo = generatedCopy.howToUseSo
                )
                onAddGeneratedProduct(product)
            },
            shape = RoundedCornerShape(12.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2E7D32)),
            modifier = Modifier.fillMaxWidth().height(50.dp).testTag("add_ai_product_to_store_button")
        ) {
            Text("Publish to Catalog with AI Copy (نشر في المتجر)", fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun DebitRequestsTab(
    requests: List<DebitRequest>,
    language: AppLanguage,
    isDark: Boolean,
    onInspect: (DebitRequest) -> Unit,
    onApprove: (DebitRequest) -> Unit,
    onReject: (DebitRequest) -> Unit
) {
    if (requests.isEmpty()) {
        Box(
            modifier = Modifier.fillMaxSize().padding(32.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = "No pending debit requests yet.\nWhen customers request to Pay Later with NIRA ID, they will appear here.",
                fontSize = 13.sp,
                textAlign = TextAlign.Center,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    } else {
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(requests, key = { it.id }) { req ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = if (isDark) Color(0xFF1E1916) else Color(0xFFFFFDF9)
                    ),
                    border = BorderStroke(
                        1.dp,
                        when (req.status) {
                            DebitStatus.APPROVED -> Color(0xFF2E7D32)
                            DebitStatus.REJECTED -> Color(0xFFC62828)
                            DebitStatus.PENDING -> if (isDark) GoldBorderDark else GoldBorderLight
                        }
                    )
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = req.id,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isDark) GoldGlow else Color(0xFFB8860B)
                            )
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = when (req.status) {
                                    DebitStatus.APPROVED -> Color(0xFF2E7D32)
                                    DebitStatus.REJECTED -> Color(0xFFC62828)
                                    DebitStatus.PENDING -> Color(0xFFF57C00)
                                }
                            ) {
                                Text(
                                    text = req.status.name,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(6.dp))

                        Text(
                            text = "👤 ${req.fullName}",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = "📱 ${req.phoneNumber} • 📍 ${req.placeOrCity}",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            text = "📅 Due: ${req.promisedPaymentDate} • 💰 Total: $${String.format(java.util.Locale.US, "%.2f", req.totalAmountUsd)}",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = if (isDark) GoldGlow else Color(0xFF8B6508)
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        // Action buttons: Inspect Documents, Approve, Reject
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Button(
                                onClick = { onInspect(req) },
                                shape = RoundedCornerShape(10.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF455A64)),
                                modifier = Modifier.weight(1f).height(38.dp)
                            ) {
                                Text("Inspect ID", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }

                            if (req.status == DebitStatus.PENDING) {
                                Button(
                                    onClick = { onApprove(req) },
                                    shape = RoundedCornerShape(10.dp),
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2E7D32)),
                                    modifier = Modifier.weight(1f).height(38.dp)
                                ) {
                                    Text("Approve", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }

                                Button(
                                    onClick = { onReject(req) },
                                    shape = RoundedCornerShape(10.dp),
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFC62828)),
                                    modifier = Modifier.weight(1f).height(38.dp)
                                ) {
                                    Text("Reject", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun InspectDebitModal(
    request: DebitRequest,
    language: AppLanguage,
    isDark: Boolean,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text("NIRA ID Verification Documents", fontSize = 16.sp, fontWeight = FontWeight.Bold)
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
            ) {
                Text(
                    text = "Customer: ${request.fullName}",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Phone: ${request.phoneNumber} • City: ${request.placeOrCity}",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    text = "Promised Repayment Date: ${request.promisedPaymentDate}",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = if (isDark) GoldGlow else Color(0xFF8B6508)
                )

                Spacer(modifier = Modifier.height(12.dp))

                Text("Front Side NIRA ID:", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(4.dp))
                if (request.frontIdUri != null) {
                    AsyncImage(
                        model = request.frontIdUri,
                        contentDescription = "Front ID",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(140.dp)
                            .clip(RoundedCornerShape(8.dp))
                    )
                } else {
                    Text("No front photo attached", fontSize = 11.sp, color = MaterialTheme.colorScheme.error)
                }

                Spacer(modifier = Modifier.height(12.dp))

                Text("Back Side NIRA ID:", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(4.dp))
                if (request.backIdUri != null) {
                    AsyncImage(
                        model = request.backIdUri,
                        contentDescription = "Back ID",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(140.dp)
                            .clip(RoundedCornerShape(8.dp))
                    )
                } else {
                    Text("No back photo attached", fontSize = 11.sp, color = MaterialTheme.colorScheme.error)
                }

                Spacer(modifier = Modifier.height(12.dp))
                Text("Ordered Products:", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Text(request.itemsSummary, fontSize = 11.sp, lineHeight = 16.sp)
            }
        },
        confirmButton = {
            Button(onClick = onDismiss) {
                Text("Close")
            }
        }
    )
}

@Composable
private fun ProductFormDialog(
    product: Product?,
    language: AppLanguage,
    isDark: Boolean,
    onDismiss: () -> Unit,
    onSave: (Product) -> Unit
) {
    var nameEn by remember { mutableStateOf(product?.nameEn ?: "") }
    var nameAr by remember { mutableStateOf(product?.nameAr ?: "") }
    var priceText by remember { mutableStateOf(product?.priceUsd?.toString() ?: "20.00") }
    var volumeText by remember { mutableStateOf(product?.volumeOrSize ?: "50 ml") }
    var selectedCategory by remember { mutableStateOf(product?.category ?: ProductCategory.SKINCARE) }
    var customImageUri by remember { mutableStateOf(product?.customImageUri) }

    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            customImageUri = uri.toString()
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                if (product == null) AppStrings.addNewProduct(language) else AppStrings.editProduct(language),
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
            ) {
                // Photo Picker from Device Gallery
                Button(
                    onClick = {
                        photoPickerLauncher.launch(
                            PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                        )
                    },
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFB8860B)),
                    modifier = Modifier.fillMaxWidth().testTag("pick_product_photo_button")
                ) {
                    Icon(Icons.Default.AddPhotoAlternate, contentDescription = null)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(AppStrings.uploadProductPhoto(language), fontSize = 12.sp)
                }

                if (customImageUri != null) {
                    Spacer(modifier = Modifier.height(8.dp))
                    AsyncImage(
                        model = customImageUri,
                        contentDescription = "Preview",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(100.dp)
                            .clip(RoundedCornerShape(8.dp))
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = nameEn,
                    onValueChange = { nameEn = it },
                    label = { Text("Product Name (English)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = nameAr,
                    onValueChange = { nameAr = it },
                    label = { Text("اسم المنتج (العربية)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = priceText,
                    onValueChange = { priceText = it },
                    label = { Text("Price (USD)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = volumeText,
                    onValueChange = { volumeText = it },
                    label = { Text("Volume / Size (e.g. 50 ml)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val price = priceText.toDoubleOrNull() ?: 20.0
                    val newProduct = product?.copy(
                        nameEn = nameEn.ifBlank { "Beauty Item" },
                        nameAr = nameAr.ifBlank { "مستحضر تجميلي" },
                        priceUsd = price,
                        volumeOrSize = volumeText,
                        category = selectedCategory,
                        customImageUri = customImageUri
                    ) ?: Product(
                        id = "prod_" + UUID.randomUUID().toString().take(6),
                        nameEn = nameEn.ifBlank { "Luxury Cosmetic" },
                        nameAr = nameAr.ifBlank { "مستحضر فاخر" },
                        nameSo = nameEn,
                        category = selectedCategory,
                        priceUsd = price,
                        originalPriceUsd = price * 1.3,
                        imageResName = "item_gold_serum",
                        customImageUri = customImageUri,
                        volumeOrSize = volumeText,
                        descriptionEn = "A signature luxury cosmetic by Umm Yousef Online Shopping.",
                        descriptionAr = "مستحضر فاخر من مختارات أم يوسف للجمال. جمالك الطبيعي، لمستنا الساحرة.",
                        descriptionSo = "Agab quruxeed qaali ah oo ka socda Umm Yousef Online Shopping."
                    )
                    onSave(newProduct)
                }
            ) {
                Text("Save")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}

package com.example.model

enum class AppLanguage(val code: String, val displayName: String, val nativeName: String, val isRtl: Boolean) {
    ARABIC("ar", "Arabic", "العربية", true),
    SOMALI("so", "Somali", "Af-Soomaali", false),
    ENGLISH("en", "English", "English", false)
}

enum class AppThemeMode {
    LIGHT,
    DARK,
    SYSTEM
}

enum class ProductCategory(val id: String) {
    ALL("all"),
    SKINCARE("skincare"),
    HAIRCARE("haircare"),
    PERFUMES_OUD("perfumes_oud"),
    MAKEUP("makeup"),
    BATH_BODY("bath_body"),
    NATURAL_OILS("natural_oils")
}

data class Product(
    val id: String,
    val nameEn: String,
    val nameAr: String,
    val nameSo: String,
    val category: ProductCategory,
    val priceUsd: Double,
    val originalPriceUsd: Double? = null,
    val imageResName: String, // e.g. "item_gold_serum", "item_royal_oud", etc.
    val customImageUri: String? = null,
    val volumeOrSize: String,
    val rating: Float = 4.9f,
    val reviewsCount: Int = 124,
    val descriptionEn: String,
    val descriptionAr: String,
    val descriptionSo: String,
    val keyBenefitsEn: List<String> = emptyList(),
    val keyBenefitsAr: List<String> = emptyList(),
    val keyBenefitsSo: List<String> = emptyList(),
    val ingredientsEn: String = "",
    val ingredientsAr: String = "",
    val ingredientsSo: String = "",
    val howToUseEn: String = "",
    val howToUseAr: String = "",
    val howToUseSo: String = "",
    val inStock: Boolean = true
) {
    fun localizedName(lang: AppLanguage): String = when (lang) {
        AppLanguage.ARABIC -> nameAr.ifBlank { nameEn }
        AppLanguage.SOMALI -> nameSo.ifBlank { nameEn }
        AppLanguage.ENGLISH -> nameEn
    }

    fun localizedDescription(lang: AppLanguage): String = when (lang) {
        AppLanguage.ARABIC -> descriptionAr.ifBlank { descriptionEn }
        AppLanguage.SOMALI -> descriptionSo.ifBlank { descriptionEn }
        AppLanguage.ENGLISH -> descriptionEn
    }

    fun localizedBenefits(lang: AppLanguage): List<String> = when (lang) {
        AppLanguage.ARABIC -> if (keyBenefitsAr.isNotEmpty()) keyBenefitsAr else keyBenefitsEn
        AppLanguage.SOMALI -> if (keyBenefitsSo.isNotEmpty()) keyBenefitsSo else keyBenefitsEn
        AppLanguage.ENGLISH -> keyBenefitsEn
    }

    fun localizedIngredients(lang: AppLanguage): String = when (lang) {
        AppLanguage.ARABIC -> ingredientsAr.ifBlank { ingredientsEn }
        AppLanguage.SOMALI -> ingredientsSo.ifBlank { ingredientsEn }
        AppLanguage.ENGLISH -> ingredientsEn
    }

    fun localizedHowToUse(lang: AppLanguage): String = when (lang) {
        AppLanguage.ARABIC -> howToUseAr.ifBlank { howToUseEn }
        AppLanguage.SOMALI -> howToUseSo.ifBlank { howToUseEn }
        AppLanguage.ENGLISH -> howToUseEn
    }
}

data class CartItem(
    val product: Product,
    val quantity: Int = 1
) {
    val subtotal: Double
        get() = product.priceUsd * quantity
}

enum class DebitStatus {
    PENDING,
    APPROVED,
    REJECTED
}

data class DebitRequest(
    val id: String,
    val fullName: String,
    val phoneNumber: String,
    val placeOrCity: String,
    val promisedPaymentDate: String,
    val frontIdUri: String?,
    val backIdUri: String?,
    val itemsSummary: String,
    val totalAmountUsd: Double,
    val status: DebitStatus = DebitStatus.PENDING,
    val timestamp: Long = System.currentTimeMillis(),
    val ownerNotes: String = ""
)

data class CustomerProfile(
    val fullName: String = "",
    val phoneNumber: String = "",
    val city: String = "Mogadishu",
    val isVerified: Boolean = false
)

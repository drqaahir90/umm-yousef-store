package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import com.example.model.AppLanguage
import com.example.ui.StoreScreen
import com.example.ui.StoreViewModel
import com.example.ui.components.CustomerOnboardingDialog
import com.example.ui.components.LanguageThemeDialog
import com.example.ui.components.LuxuryTopBar
import com.example.ui.screens.CartScreen
import com.example.ui.screens.CatalogScreen
import com.example.ui.screens.CheckoutScreen
import com.example.ui.screens.OwnerPortalScreen
import com.example.ui.screens.ProductDetailScreen
import com.example.ui.theme.UmmYousefTheme
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    private val viewModel: StoreViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val currentTheme by viewModel.currentTheme.collectAsState()
            val currentLanguage by viewModel.currentLanguage.collectAsState()

            // RTL support for Arabic, LTR for Somali & English
            val layoutDirection = if (currentLanguage.isRtl) LayoutDirection.Rtl else LayoutDirection.Ltr

            CompositionLocalProvider(LocalLayoutDirection provides layoutDirection) {
                UmmYousefTheme(themeMode = currentTheme) {
                    UmmYousefApp(viewModel = viewModel)
                }
            }
        }
    }
}

@Composable
fun UmmYousefApp(viewModel: StoreViewModel) {
    val currentScreen by viewModel.currentScreen.collectAsState()
    val currentLanguage by viewModel.currentLanguage.collectAsState()
    val currentTheme by viewModel.currentTheme.collectAsState()
    val selectedProduct by viewModel.selectedProduct.collectAsState()
    val cart by viewModel.cart.collectAsState()
    val customerProfile by viewModel.customerProfile.collectAsState()

    val totalCartCount = cart.sumOf { it.quantity }
    val snackbarHostState = remember { SnackbarHostState() }
    val coroutineScope = rememberCoroutineScope()

    var showLanguageThemeDialog by remember { mutableStateOf(false) }
    var showCustomerDialog by remember { mutableStateOf(false) }

    // Intercept back button when not on Catalog
    BackHandler(enabled = currentScreen != StoreScreen.CATALOG) {
        when (currentScreen) {
            StoreScreen.PRODUCT_DETAIL -> viewModel.navigateTo(StoreScreen.CATALOG)
            StoreScreen.BASKET -> viewModel.navigateTo(StoreScreen.CATALOG)
            StoreScreen.CHECKOUT -> viewModel.navigateTo(StoreScreen.BASKET)
            StoreScreen.OWNER_PORTAL -> viewModel.navigateTo(StoreScreen.CATALOG)
            StoreScreen.CUSTOMER_ONBOARDING -> viewModel.navigateTo(StoreScreen.CATALOG)
            StoreScreen.CATALOG -> { /* exit handled by OS */ }
        }
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            if (currentScreen == StoreScreen.CATALOG) {
                LuxuryTopBar(
                    language = currentLanguage,
                    themeMode = currentTheme,
                    cartItemCount = totalCartCount,
                    onLanguageClick = { showLanguageThemeDialog = true },
                    onThemeClick = { showLanguageThemeDialog = true },
                    onCartClick = { viewModel.navigateTo(StoreScreen.BASKET) },
                    onOwnerClick = { viewModel.navigateTo(StoreScreen.OWNER_PORTAL) },
                    onCustomerProfileClick = { showCustomerDialog = true },
                    customerName = customerProfile.fullName
                )
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            AnimatedContent(
                targetState = currentScreen,
                transitionSpec = { fadeIn() togetherWith fadeOut() },
                label = "ScreenTransition"
            ) { screen ->
                when (screen) {
                    StoreScreen.CATALOG -> {
                        CatalogScreen(
                            viewModel = viewModel,
                            onProductClick = { product ->
                                viewModel.openProductDetail(product)
                            },
                            onOrderNowDirect = { product ->
                                viewModel.addToCart(product, 1)
                                viewModel.navigateTo(StoreScreen.CHECKOUT)
                            }
                        )
                    }

                    StoreScreen.PRODUCT_DETAIL -> {
                        selectedProduct?.let { product ->
                            ProductDetailScreen(
                                product = product,
                                language = currentLanguage,
                                onBackClick = { viewModel.navigateTo(StoreScreen.CATALOG) },
                                onAddToCart = { qty ->
                                    viewModel.addToCart(product, qty)
                                    coroutineScope.launch {
                                        snackbarHostState.showSnackbar(
                                            message = when (currentLanguage) {
                                                AppLanguage.ARABIC -> "تمت إضافة ${product.nameAr} إلى السلة ✨"
                                                AppLanguage.SOMALI -> "Waxaa lagu daray dambiisha ✨"
                                                AppLanguage.ENGLISH -> "Added ${product.nameEn} to basket ✨"
                                            }
                                        )
                                    }
                                },
                                onOrderNow = { qty ->
                                    viewModel.addToCart(product, qty)
                                    viewModel.navigateTo(StoreScreen.CHECKOUT)
                                }
                            )
                        } ?: run {
                            viewModel.navigateTo(StoreScreen.CATALOG)
                        }
                    }

                    StoreScreen.BASKET -> {
                        CartScreen(
                            viewModel = viewModel,
                            onBackClick = { viewModel.navigateTo(StoreScreen.CATALOG) },
                            onProceedToCheckout = { viewModel.navigateTo(StoreScreen.CHECKOUT) }
                        )
                    }

                    StoreScreen.CHECKOUT -> {
                        CheckoutScreen(
                            viewModel = viewModel,
                            onBackClick = { viewModel.navigateTo(StoreScreen.BASKET) },
                            onOrderComplete = {
                                coroutineScope.launch {
                                    snackbarHostState.showSnackbar(
                                        message = when (currentLanguage) {
                                            AppLanguage.ARABIC -> "شكراً لتسوقك من أم يوسف للجمال! تم إرسال الطلب ✨"
                                            AppLanguage.SOMALI -> "Waad ku mahadsan tahay wax ka iibsashada Umm Yousef! ✨"
                                            AppLanguage.ENGLISH -> "Thank you for shopping with Umm Yousef Beauty! ✨"
                                        }
                                    )
                                }
                                viewModel.navigateTo(StoreScreen.CATALOG)
                            }
                        )
                    }

                    StoreScreen.OWNER_PORTAL -> {
                        OwnerPortalScreen(
                            viewModel = viewModel,
                            onBackClick = { viewModel.navigateTo(StoreScreen.CATALOG) }
                        )
                    }

                    StoreScreen.CUSTOMER_ONBOARDING -> {
                        viewModel.navigateTo(StoreScreen.CATALOG)
                    }
                }
            }
        }
    }

    // Language & Theme Customization Modal
    if (showLanguageThemeDialog) {
        LanguageThemeDialog(
            currentLanguage = currentLanguage,
            currentTheme = currentTheme,
            onLanguageChange = { viewModel.setLanguage(it) },
            onThemeChange = { viewModel.setTheme(it) },
            onDismiss = { showLanguageThemeDialog = false }
        )
    }

    // Customer WhatsApp Onboarding Modal
    if (showCustomerDialog) {
        CustomerOnboardingDialog(
            currentProfile = customerProfile,
            language = currentLanguage,
            onDismiss = { showCustomerDialog = false },
            onSaveAndConnectWhatsApp = { name, phone, city ->
                viewModel.saveCustomerProfile(name, phone, city)
            }
        )
    }
}

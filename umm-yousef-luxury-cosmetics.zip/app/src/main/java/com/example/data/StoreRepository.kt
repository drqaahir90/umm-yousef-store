package com.example.data

import android.content.Context
import android.content.SharedPreferences
import com.example.model.AppLanguage
import com.example.model.AppThemeMode
import com.example.model.CartItem
import com.example.model.CustomerProfile
import com.example.model.DebitRequest
import com.example.model.DebitStatus
import com.example.model.Product
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.UUID

class StoreRepository(context: Context) {
    private val prefs: SharedPreferences = context.getSharedPreferences("umm_yousef_store", Context.MODE_PRIVATE)

    private val _products = MutableStateFlow<List<Product>>(SampleProducts.getInitialProducts())
    val products: StateFlow<List<Product>> = _products.asStateFlow()

    private val _cart = MutableStateFlow<List<CartItem>>(emptyList())
    val cart: StateFlow<List<CartItem>> = _cart.asStateFlow()

    private val _debitRequests = MutableStateFlow<List<DebitRequest>>(emptyList())
    val debitRequests: StateFlow<List<DebitRequest>> = _debitRequests.asStateFlow()

    private val _currentLanguage = MutableStateFlow(
        try {
            AppLanguage.valueOf(prefs.getString("lang", AppLanguage.ARABIC.name) ?: AppLanguage.ARABIC.name)
        } catch (_: Exception) {
            AppLanguage.ARABIC
        }
    )
    val currentLanguage: StateFlow<AppLanguage> = _currentLanguage.asStateFlow()

    private val _currentTheme = MutableStateFlow(
        try {
            AppThemeMode.valueOf(prefs.getString("theme", AppThemeMode.LIGHT.name) ?: AppThemeMode.LIGHT.name)
        } catch (_: Exception) {
            AppThemeMode.LIGHT
        }
    )
    val currentTheme: StateFlow<AppThemeMode> = _currentTheme.asStateFlow()

    private val _customerProfile = MutableStateFlow(
        CustomerProfile(
            fullName = prefs.getString("cust_name", "") ?: "",
            phoneNumber = prefs.getString("cust_phone", "") ?: "",
            city = prefs.getString("cust_city", "Mogadishu") ?: "Mogadishu",
            isVerified = prefs.getBoolean("cust_verified", false)
        )
    )
    val customerProfile: StateFlow<CustomerProfile> = _customerProfile.asStateFlow()

    fun setLanguage(language: AppLanguage) {
        _currentLanguage.value = language
        prefs.edit().putString("lang", language.name).apply()
    }

    fun setTheme(theme: AppThemeMode) {
        _currentTheme.value = theme
        prefs.edit().putString("theme", theme.name).apply()
    }

    fun saveCustomerProfile(name: String, phone: String, city: String) {
        val updated = CustomerProfile(
            fullName = name.trim(),
            phoneNumber = phone.trim(),
            city = city.trim().ifBlank { "Mogadishu" },
            isVerified = true
        )
        _customerProfile.value = updated
        prefs.edit()
            .putString("cust_name", updated.fullName)
            .putString("cust_phone", updated.phoneNumber)
            .putString("cust_city", updated.city)
            .putBoolean("cust_verified", true)
            .apply()
    }

    // Cart management
    fun addToCart(product: Product, quantity: Int = 1) {
        val current = _cart.value.toMutableList()
        val index = current.indexOfFirst { it.product.id == product.id }
        if (index >= 0) {
            val existing = current[index]
            current[index] = existing.copy(quantity = existing.quantity + quantity)
        } else {
            current.add(CartItem(product = product, quantity = quantity))
        }
        _cart.value = current
    }

    fun updateCartQuantity(productId: String, newQuantity: Int) {
        val current = _cart.value.toMutableList()
        val index = current.indexOfFirst { it.product.id == productId }
        if (index >= 0) {
            if (newQuantity <= 0) {
                current.removeAt(index)
            } else {
                current[index] = current[index].copy(quantity = newQuantity)
            }
            _cart.value = current
        }
    }

    fun removeFromCart(productId: String) {
        _cart.value = _cart.value.filter { it.product.id != productId }
    }

    fun clearCart() {
        _cart.value = emptyList()
    }

    // Product management (Owner Portal)
    fun addProduct(product: Product) {
        _products.value = listOf(product) + _products.value
    }

    fun updateProduct(product: Product) {
        _products.value = _products.value.map {
            if (it.id == product.id) product else it
        }
    }

    fun deleteProduct(productId: String) {
        _products.value = _products.value.filter { it.id != productId }
    }

    // Debit Application management
    fun submitDebitRequest(
        fullName: String,
        phone: String,
        place: String,
        promisedDate: String,
        frontIdUri: String?,
        backIdUri: String?,
        itemsSummary: String,
        totalAmount: Double
    ): DebitRequest {
        val request = DebitRequest(
            id = "DEBIT-" + UUID.randomUUID().toString().take(8).uppercase(),
            fullName = fullName,
            phoneNumber = phone,
            placeOrCity = place,
            promisedPaymentDate = promisedDate,
            frontIdUri = frontIdUri,
            backIdUri = backIdUri,
            itemsSummary = itemsSummary,
            totalAmountUsd = totalAmount,
            status = DebitStatus.PENDING
        )
        _debitRequests.value = listOf(request) + _debitRequests.value
        return request
    }

    fun updateDebitStatus(requestId: String, status: DebitStatus, notes: String = "") {
        _debitRequests.value = _debitRequests.value.map {
            if (it.id == requestId) it.copy(status = status, ownerNotes = notes) else it
        }
    }
}

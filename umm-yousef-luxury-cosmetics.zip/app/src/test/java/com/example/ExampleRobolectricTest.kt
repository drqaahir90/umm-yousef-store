package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.SampleProducts
import com.example.model.AppLanguage
import com.example.model.ProductCategory
import com.example.util.AiCopywriter
import com.example.util.AppStrings
import com.example.util.EVCPlusHelper
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

    @Test
    fun `read string from context matches Umm Yousef Beauty`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("Umm Yousef Beauty", appName)
    }

    @Test
    fun `verify EVC Plus USSD code formatting`() {
        val ussd = EVCPlusHelper.generateUssdCode(35.0)
        assertEquals("*712*613679490*35#", ussd)

        val ussdDecimal = EVCPlusHelper.generateUssdCode(22.5)
        assertEquals("*712*613679490*22.5#", ussdDecimal)
    }

    @Test
    fun `verify sample products catalog and translations`() {
        val products = SampleProducts.getInitialProducts()
        assertTrue("Products should not be empty", products.isNotEmpty())

        val serum = products.first { it.id == "prod_1" }
        assertEquals(ProductCategory.SKINCARE, serum.category)
        assertTrue(serum.localizedName(AppLanguage.ARABIC).contains("الذهب"))
        assertTrue(serum.localizedDescription(AppLanguage.ARABIC).contains(AppStrings.SLOGAN_AR) || serum.localizedDescription(AppLanguage.ARABIC).contains("الذهب"))
        assertNotNull(serum.imageResName)
    }

    @Test
    fun `verify AI copywriting engine output in all three languages`() {
        val copy = AiCopywriter.generateProductCopy(
            productName = "Rose Illuminating Cream",
            category = ProductCategory.SKINCARE,
            keyIngredientsOrFeature = "Bulgarian Rose Water & 24K Gold"
        )
        assertTrue(copy.descriptionAr.contains("أم يوسف للجمال"))
        assertTrue(copy.descriptionEn.contains("Umm Yousef Beauty"))
        assertTrue(copy.descriptionSo.contains("Umm Yousef Beauty"))
        assertTrue(copy.benefitsAr.isNotEmpty())
        assertTrue(copy.benefitsEn.isNotEmpty())
    }
}
